/* WRITING — archive index + article reader, hash-routed (writing.html#slug) */
(function () {
  "use strict";
  var U = window.U, S = window.SITE || {};
  var main = document.getElementById("main");

  var posts = (window.WRITING || []).filter(function (w) { return !w.draft; })
    .sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });

  var GLYPH = { seedling: "◌", budding: "◐", evergreen: "●" };
  function status(s) { return s ? '<span class="status" title="' + U.esc(s) + '"><span aria-hidden="true">' + (GLYPH[s] || "○") + "</span> " + U.esc(s) + "</span>" : ""; }

  /* ---------- maths: load KaTeX only when an article actually needs it ---------- */
  var katexReady = null;
  function loadKatex() {
    if (katexReady) return katexReady;
    katexReady = new Promise(function (resolve, reject) {
      var css = document.createElement("link");
      css.rel = "stylesheet";
      css.href = "https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css";
      document.head.appendChild(css);
      var core = document.createElement("script");
      core.src = "https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.js";
      core.onload = function () {
        var auto = document.createElement("script");
        auto.src = "https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/contrib/auto-render.min.js";
        auto.onload = resolve;
        auto.onerror = reject;
        document.head.appendChild(auto);
      };
      core.onerror = reject;
      document.head.appendChild(core);
    });
    return katexReady;
  }
  function typesetMath(root, body) {
    if (!root || !/(\$|\\\(|\\\[)/.test(body || "")) return;
    loadKatex().then(function () {
      if (!window.renderMathInElement || !root.isConnected) return;
      window.renderMathInElement(root, {
        delimiters: [
          { left: "$$", right: "$$", display: true },
          { left: "\\[", right: "\\]", display: true },
          { left: "$", right: "$", display: false },
          { left: "\\(", right: "\\)", display: false }
        ],
        throwOnError: false
      });
    }).catch(function () { /* offline: leave the TeX readable */ });
  }

  /* ---------- index ---------- */
  function renderIndex() {
    U.setTitle("Writing");
    var byYear = {}, years = [];
    posts.forEach(function (p) { var y = U.year(p.date) || "—"; if (!byYear[y]) { byYear[y] = []; years.push(y); } byYear[y].push(p); });

    var html =
      '<div class="notebook">' +
        '<header class="nb-head rise">' +
          '<p class="mono muted">Notebook · ' + posts.length + (posts.length === 1 ? " entry" : " entries") + "</p>" +
          '<h1 class="nb-title">Writing</h1>' +
          (S.writingIntro ? '<p class="nb-intro">' + U.esc(S.writingIntro) + "</p>" : "") +
        "</header>" +
        (posts.length ? years.map(function (y) {
          return '<section class="year" aria-label="' + y + '"><h2 class="year__h mono">' + y + '</h2><ol class="entries">' +
            byYear[y].map(function (p) {
              return '<li class="entry"><a class="entry__a" href="#' + U.esc(p.slug) + '">' +
                '<span class="entry__date mono">' + U.esc(U.fmtDate(p.date)) + "</span>" +
                '<span class="entry__main"><span class="entry__t">' + U.esc(p.title) + "</span>" +
                (p.description ? '<span class="entry__d">' + U.esc(p.description) + "</span>" : "") + "</span>" +
                '<span class="entry__meta mono"><span>' + U.esc(p.category || "") + "</span>" + status(p.status) + "</span></a></li>";
            }).join("") + "</ol></section>";
        }).join("") : U.empty("Nothing here yet — add an article in content/writing.js.")) +
      "</div>";
    main.innerHTML = html;
  }

  /* ---------- article ---------- */
  function renderArticle(p, idx) {
    U.setTitle(p.title);
    var r = U.md(p.body), prev = posts[idx + 1], next = posts[idx - 1];
    var toc = r.toc.length > 1
      ? '<nav class="toc" aria-label="Contents"><p class="mono muted">Contents</p><ol>' + r.toc.map(function (t) { return '<li><a href="#" data-target="' + U.esc(t.id) + '">' + U.esc(t.text) + "</a></li>"; }).join("") + "</ol></nav>"
      : "";
    main.innerHTML =
      '<div class="reader">' +
        '<p class="reader__back mono"><a href="writing.html">← Writing</a></p>' +
        toc +
        '<article class="article">' +
          '<header class="article__head rise">' +
            '<p class="article__meta mono"><span>' + U.esc(U.fmtDate(p.date)) + "</span>" + (p.category ? "<span>" + U.esc(p.category) + "</span>" : "") + status(p.status) + "<span>" + U.readingTime(p.body) + "</span></p>" +
            '<h1 class="article__title">' + U.esc(p.title) + "</h1>" +
            (p.description ? '<p class="article__standfirst">' + U.esc(p.description) + "</p>" : "") +
          "</header>" +
          '<div class="prose">' + r.html + "</div>" +
        "</article>" +
        '<nav class="pager" aria-label="More writing">' +
          (prev ? '<a class="pager__a" href="#' + U.esc(prev.slug) + '"><span class="mono muted">← Earlier</span><span class="pager__t">' + U.esc(prev.title) + "</span></a>" : "<span></span>") +
          (next ? '<a class="pager__a pager__a--r" href="#' + U.esc(next.slug) + '"><span class="mono muted">Later →</span><span class="pager__t">' + U.esc(next.title) + "</span></a>" : "<span></span>") +
        "</nav>" +
      "</div>";

    main.querySelectorAll(".toc a").forEach(function (a) {
      a.addEventListener("click", function (e) {
        e.preventDefault();
        var el = document.getElementById(a.dataset.target);
        if (el) el.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
      });
    });
  }

  function route() {
    var slug = decodeURIComponent(location.hash.slice(1));
    var idx = -1;
    posts.forEach(function (p, i) { if (p.slug === slug) idx = i; });
    if (idx >= 0) renderArticle(posts[idx], idx); else renderIndex();
    window.scrollTo(0, 0);
    main.focus({ preventScroll: true });
  }

  window.addEventListener("hashchange", route);
  route();
})();
