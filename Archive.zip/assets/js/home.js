/* HOME — renders the editorial homepage from content/site.js and writing.js */
(function () {
  "use strict";
  var U = window.U, S = window.SITE || {}, H = S.home || {};
  var main = document.getElementById("main");
  U.setTitle("");

  var words = String(S.name || "Your Name").trim().split(/\s+/);
  // horizontal offsets for each word of the name (vw) — deliberately uneven
  var OFFSETS = [0, 17, 5, 22, 2];

  var writing = (window.WRITING || []).filter(function (w) { return !w.draft && w.featured; })
    .sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); }).slice(0, 5);
  function link(href, html, cls) { return '<a class="' + (cls || "") + '" href="' + href + '">' + html + "</a>"; }

  /* ---------- 1. composition: name, portrait, intro, marginalia ---------- */
  var hero =
    '<section class="hero" aria-labelledby="name">' +
      '<p class="hero__meta mono rise" style="--i:1">' +
        (S.location ? U.esc(S.location) + "<br>" : "") +
        (S.updated ? '<span class="muted">Updated ' + U.esc(S.updated) + "</span>" : "") +
      "</p>" +
      '<nav class="hero__index mono rise" style="--i:2" aria-label="Sections">' +
        '<a href="writing.html"><span class="muted">01</span> Writing</a>' +
        '<a href="projects.html"><span class="muted">02</span> Projects</a>' +
        '<a href="reading.html"><span class="muted">03</span> Reading</a>' +
      "</nav>" +
      '<figure class="hero__fig rise" style="--i:3">' +
        (H.portrait
          ? '<img src="' + U.esc(H.portrait) + '" alt="' + U.esc(S.name || "Portrait") + '" decoding="async">'
          : '<div class="ph" role="img" aria-label="Portrait placeholder"><span>portrait<br>assets/img/…</span></div>') +
        (H.portraitCaption ? '<figcaption class="mono mono--lc">' + U.esc(H.portraitCaption) + "</figcaption>" : "") +
      "</figure>" +
      '<h1 class="name" id="name" aria-label="' + U.esc(S.name || "") + '">' +
        words.map(function (w, i) {
          return '<span class="name__w' + (i % 2 ? " name__w--i" : "") + ' rise" style="--ox:' + OFFSETS[i % OFFSETS.length] + "vw;--i:" + (i + 2) + '" aria-hidden="true">' + U.esc(w) + "</span>";
        }).join("") +
      "</h1>" +
      (H.intro ? '<p class="hero__intro rise" style="--i:5">' + U.esc(H.intro) + "</p>" : "") +
      ((H.topics || []).length
        ? '<ul class="hero__topics mono rise" style="--i:6" aria-label="Interests">' + H.topics.map(function (t) { return "<li>" + U.esc(t) + "</li>"; }).join("") + "</ul>"
        : "") +
      (H.marginalia || []).slice(0, 3).map(function (m, i) {
        return '<p class="note note--' + (i + 1) + ' mono mono--lc rise" style="--i:' + (7 + i) + '"><span aria-hidden="true">' + ["↘", "↖", "↙"][i] + "</span> " + U.esc(m) + "</p>";
      }).join("") +
    "</section>";

  /* ---------- 2. statement ---------- */
  var statement = H.statement
    ? '<section class="statement reveal" aria-label="Statement"><p class="statement__label mono muted">§ Intent</p><p class="statement__text">' + U.inlineItalic(H.statement) + "</p></section>"
    : "";

  /* ---------- 3. selected writing: a staggered index, not cards ---------- */
  var writingHtml = '<section class="sel sel--writing" aria-labelledby="h-writing">' +
    '<header class="sel__head reveal"><h2 id="h-writing" class="mono">(A) Selected writing</h2>' + link("writing.html", "All writing →", "mono sel__all") + "</header>" +
    (writing.length
      ? '<ol class="wlist">' + writing.map(function (w, i) {
          return '<li class="wlist__item reveal" style="--s:' + [0, 7, 3, 10, 1][i % 5] + 'vw">' +
            '<a href="writing.html#' + U.esc(w.slug) + '">' +
              '<span class="wlist__n mono muted">' + U.pad(i + 1) + "</span>" +
              '<span class="wlist__t">' + U.esc(w.title) + "</span>" +
              '<span class="wlist__m mono"><span>' + U.esc(w.category || "") + "</span><span class=\"muted\">" + U.fmtShort(w.date) + "·" + U.year(w.date) + "</span></span>" +
              (w.description ? '<span class="wlist__d">' + U.esc(w.description) + "</span>" : "") +
            "</a></li>";
        }).join("") + "</ol>"
      : U.empty("No featured writing yet — set <code>featured: true</code> on an article in content/writing.js."))
    + "</section>";

  /* ---------- 4. experience ---------- */
  var cvRows = (S.cv || []);
  var cv = cvRows.length
    ? '<section class="cv" aria-labelledby="h-cv"><h2 id="h-cv" class="cv__h mono reveal">(B) Experience</h2><ol class="cv__list">' +
      cvRows.map(function (r) {
        return '<li class="cv__row reveal"><span class="cv__y mono">' + U.esc(r.years || "") + '</span><span class="cv__t">' + U.esc(r.title || "") + "</span>" +
          '<span class="cv__p"><span>' + U.esc(r.place || "") + "</span>" + (r.note ? '<span class="muted">' + U.esc(r.note) + "</span>" : "") + "</span></li>";
      }).join("") + "</ol></section>"
    : "";

  /* ---------- 5. say hello ---------- */
  var hello = S.email
    ? '<section class="hello reveal" aria-label="Contact"><p class="mono muted">(C) Contact</p><a class="hello__a" href="mailto:' + U.esc(S.email) + '">Say hello<span class="hello__arrow" aria-hidden="true"> ↗</span></a><p class="hello__m mono mono--lc">' + U.esc(S.email) + "</p></section>"
    : "";

  main.innerHTML = hero + statement + writingHtml + cv + hello;
  U.reveal(main);
})();
