/* PROJECTS — archive index + case studies, hash-routed (projects.html#slug) */
(function () {
  "use strict";
  var U = window.U, S = window.SITE || {};
  var main = document.getElementById("main");
  var projects = (window.PROJECTS || []).filter(function (p) { return !p.draft; });
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var live = []; // running simulations, stopped on route change

  /* ======================================================================
     Pheromone field — a tiny scalar-field simulation used for tiles, hero
     and the interactive demo block. Agents sense the field ahead of them,
     steer up the gradient and deposit more; the field diffuses and evaporates.
     ====================================================================== */
  function mountField(canvas, opt) {
    opt = opt || {};
    var W = opt.w || 96, H = opt.h || 56, N = opt.agents || 60;
    var f = new Float32Array(W * H), g = new Float32Array(W * H);
    var evap = opt.evap != null ? opt.evap : 0.02, diff = opt.diff != null ? opt.diff : 0.3;
    canvas.width = W; canvas.height = H;
    var ctx = canvas.getContext("2d"), img = ctx.createImageData(W, H);
    var m = /(\d+)[, ]+(\d+)[, ]+(\d+)/.exec(getComputedStyle(canvas).color) || [0, 194, 207, 134];
    var C = [+m[1], +m[2], +m[3]], B = [14, 16, 14];
    var agents = [], running = false, raf = 0, visible = true;

    function seed() {
      f.fill(0); agents = [];
      for (var i = 0; i < N; i++) agents.push({ x: Math.random() * W, y: Math.random() * H, a: Math.random() * 6.283 });
    }
    function at(x, y) {
      x = Math.floor(x); y = Math.floor(y);
      if (x < 0 || y < 0 || x >= W || y >= H) return 0;
      return f[y * W + x];
    }
    function step() {
      for (var i = 0; i < agents.length; i++) {
        var a = agents[i], d = 3.2, s = 0.7;
        var l = at(a.x + Math.cos(a.a - s) * d, a.y + Math.sin(a.a - s) * d);
        var c = at(a.x + Math.cos(a.a) * d, a.y + Math.sin(a.a) * d);
        var r = at(a.x + Math.cos(a.a + s) * d, a.y + Math.sin(a.a + s) * d);
        if (c >= l && c >= r) a.a += (Math.random() - .5) * .25;
        else if (l > r) a.a -= .32; else a.a += .32;
        a.a += (Math.random() - .5) * .22;
        a.x += Math.cos(a.a) * .8; a.y += Math.sin(a.a) * .8;
        if (a.x < 0 || a.x >= W) { a.a = Math.PI - a.a; a.x = Math.max(0, Math.min(W - .01, a.x)); }
        if (a.y < 0 || a.y >= H) { a.a = -a.a; a.y = Math.max(0, Math.min(H - .01, a.y)); }
        var idx = (a.y | 0) * W + (a.x | 0); f[idx] = Math.min(4, f[idx] + .55);
      }
      for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
        var k = y * W + x;
        var n = (f[y > 0 ? k - W : k] + f[y < H - 1 ? k + W : k] + f[x > 0 ? k - 1 : k] + f[x < W - 1 ? k + 1 : k]) * .25;
        g[k] = (f[k] * (1 - diff) + n * diff) * (1 - evap);
      }
      var t = f; f = g; g = t;
    }
    function draw() {
      var d = img.data;
      for (var k = 0; k < W * H; k++) {
        var v = Math.min(1, f[k] * .55), o = k * 4;
        d[o] = B[0] + (C[0] - B[0]) * v; d[o + 1] = B[1] + (C[1] - B[1]) * v; d[o + 2] = B[2] + (C[2] - B[2]) * v; d[o + 3] = 255;
      }
      for (var i = 0; i < agents.length; i++) {
        var o2 = ((agents[i].y | 0) * W + (agents[i].x | 0)) * 4;
        d[o2] = 240; d[o2 + 1] = 244; d[o2 + 2] = 225;
      }
      ctx.putImageData(img, 0, 0);
    }
    function loop() { if (!running) return; if (visible) { step(); draw(); } raf = requestAnimationFrame(loop); }
    function deposit(e) {
      var rc = canvas.getBoundingClientRect();
      var cx = (e.clientX - rc.left) / rc.width * W, cy = (e.clientY - rc.top) / rc.height * H;
      for (var dy = -3; dy <= 3; dy++) for (var dx = -3; dx <= 3; dx++) {
        var x = Math.floor(cx + dx), y = Math.floor(cy + dy);
        if (x >= 0 && y >= 0 && x < W && y < H && dx * dx + dy * dy <= 10) f[y * W + x] = Math.min(4, f[y * W + x] + 1.6);
      }
      if (!running) draw();
    }
    seed();
    for (var w = 0; w < 80; w++) step();
    draw();

    if (opt.interactive) {
      var down = false;
      canvas.addEventListener("pointerdown", function (e) { down = true; canvas.setPointerCapture(e.pointerId); deposit(e); });
      canvas.addEventListener("pointermove", function (e) { if (down) deposit(e); });
      canvas.addEventListener("pointerup", function () { down = false; });
      canvas.addEventListener("pointercancel", function () { down = false; });
    }
    var io = "IntersectionObserver" in window ? new IntersectionObserver(function (en) { visible = en[0].isIntersecting; }, { threshold: 0 }) : null;
    if (io) io.observe(canvas);

    var api = {
      start: function () { if (reduce || running) return; running = true; raf = requestAnimationFrame(loop); },
      stop: function () { running = false; cancelAnimationFrame(raf); if (io) io.disconnect(); },
      reset: function () { seed(); for (var w = 0; w < 40; w++) step(); draw(); },
      set: function (k, v) { if (k === "evap") evap = v; if (k === "diff") diff = v; }
    };
    api.start(); live.push(api);
    return api;
  }

  /* ---------- small builders ---------- */
  function chips(stack) { return (stack || []).map(function (s) { return "<li>" + U.esc(s) + "</li>"; }).join(""); }
  function links(ls) {
    return (ls || []).filter(function (l) { return U.safeUrl(l.url); }).map(function (l) {
      var u = U.safeUrl(l.url);
      return '<a class="plink mono" href="' + U.esc(u) + '"' + (U.isExternal(u) ? ' rel="noopener noreferrer" target="_blank"' : "") + ">" + U.esc(l.label) + " ↗</a>";
    }).join("");
  }
  function specRows(rows) {
    return (rows || []).map(function (r) { return "<div><dt>" + U.esc(r[0]) + "</dt><dd>" + U.esc(r[1]) + "</dd></div>"; }).join("");
  }
  function termLines(lines) {
    return (lines || []).map(function (l) {
      if (l.cmd != null) return '<div class="t-line"><span class="t-prompt" aria-hidden="true">$</span> <span class="t-cmd">' + U.esc(l.cmd) + "</span></div>";
      return '<div class="t-line t-out">' + U.esc(l.out != null ? l.out : "") + "</div>";
    }).join("");
  }
  function termWindow(title, inner) {
    return '<div class="term" role="group" aria-label="Terminal example"><div class="term__bar mono"><span class="term__dots" aria-hidden="true"><i></i><i></i><i></i></span><span>' + U.esc(title) + '</span><span class="muted">zsh</span></div><div class="term__body">' + inner + "</div></div>";
  }
  function firstTerminal(p) {
    var s = (p.sections || []).filter(function (x) { return x.type === "terminal"; })[0];
    return s ? s.lines.slice(0, 5) : [{ cmd: "cat README" }, { out: p.tagline || p.summary || "" }];
  }

  /* ======================================================================
     INDEX
     ====================================================================== */
  function renderIndex() {
    U.setTitle("Projects");
    var ls = projects.length
      ? '<table class="ls"><caption class="sr-only">Project index</caption><thead class="mono"><tr><th scope="col">№</th><th scope="col">Name</th><th scope="col">Year</th><th scope="col">Status</th><th scope="col">Stack</th></tr></thead><tbody>' +
        projects.map(function (p, i) {
          return '<tr class="mono"><td class="muted">' + U.pad(i + 1) + '</td><td><a href="#' + U.esc(p.slug) + '">' + U.esc(p.title) + '</a></td><td>' + U.esc(p.year || "") + "</td><td>" + U.esc(p.status || "") + '</td><td class="muted">' + U.esc((p.stack || []).join(", ")) + "</td></tr>";
        }).join("") + "</tbody></table>"
      : "";

    var tiles = projects.map(function (p, i) {
      var n = U.pad(i + 1), head =
        '<span class="ptile__top mono"><span>' + n + "</span><span>" + U.esc(p.year || "") + (p.status ? " · " + U.esc(p.status) : "") + "</span></span>";
      var foot = '<span class="ptile__foot"><span class="ptile__title">' + U.esc(p.title) + "</span>" +
        (p.tagline ? '<span class="ptile__line">' + U.esc(p.tagline) + "</span>" : "") +
        '<ul class="chips mono" aria-label="Stack">' + chips(p.stack) + "</ul></span>";
      if (p.layout === "simulation") {
        return '<a class="ptile ptile--sim reveal" href="#' + U.esc(p.slug) + '">' + '<canvas class="ptile__canvas" data-field="mini" aria-hidden="true"></canvas>' + head + foot + "</a>";
      }
      if (p.layout === "terminal") {
        return '<a class="ptile ptile--term reveal" href="#' + U.esc(p.slug) + '">' + head +
          '<span class="ptile__termwrap">' + termWindow(String(p.title).toLowerCase(), termLines(firstTerminal(p)) + '<div class="t-line"><span class="t-prompt">$</span> <span class="cursor" aria-hidden="true"></span></div>') + "</span>" + foot + "</a>";
      }
      return '<a class="ptile ptile--std reveal" href="#' + U.esc(p.slug) + '">' + head +
        '<span class="ptile__img crop">' + (p.cover ? '<img src="' + U.esc(p.cover) + '" alt="" loading="lazy" decoding="async">' : '<span class="ph"><span>' + U.esc(p.title) + "<br>cover</span></span>") + "</span>" +
        foot + (p.specs && p.specs.length ? '<dl class="mini-specs mono">' + specRows(p.specs.slice(0, 3)) + "</dl>" : "") + "</a>";
    }).join("");

    main.innerHTML =
      '<div class="archive">' +
        '<header class="arch-head rise">' +
          '<p class="prompt mono"><span class="muted">~/</span>projects <span class="cursor" aria-hidden="true"></span></p>' +
          '<h1 class="arch-title">Projects</h1>' +
          (S.projectsIntro ? '<p class="arch-intro">' + U.esc(S.projectsIntro) + "</p>" : "") +
        "</header>" +
        ls +
        (projects.length ? '<div class="pgrid">' + tiles + "</div>" : U.empty("Nothing here yet — add a project in content/projects.js.")) +
      "</div>";

    main.querySelectorAll("canvas[data-field]").forEach(function (c) { mountField(c, { w: 128, h: 80, agents: 70 }); });
    U.reveal(main);
  }

  /* ======================================================================
     CASE STUDY
     ====================================================================== */
  function sectionHtml(s, i) {
    var idx = '<span class="sec__idx mono">§ ' + U.pad(i + 1) + "</span>";
    var head = s.heading ? '<h2 class="sec__h">' + U.esc(s.heading) + "</h2>" : "";
    switch (s.type) {
      case "text":
        return '<section class="sec sec--text reveal"><div class="sec__side">' + idx + head + '</div><div class="prose">' + U.md(s.body).html + "</div></section>";
      case "figure":
        return '<section class="sec sec--wide reveal">' + idx + U.fig(s.src, s.alt, s.caption, "16/9") + "</section>";
      case "video":
        return '<section class="sec sec--wide reveal">' + idx +
          '<figure class="fig">' + (s.src
            ? '<video controls preload="none" playsinline' + (s.poster ? ' poster="' + U.esc(s.poster) + '"' : "") + '><source src="' + U.esc(s.src) + '"></video>'
            : '<div class="ph" style="aspect-ratio:16/9" role="img" aria-label="Video placeholder"><span>video<br>assets/video/…</span></div>') +
          (s.caption ? '<figcaption class="mono mono--lc">' + U.esc(s.caption) + "</figcaption>" : "") + "</figure></section>";
      case "gallery":
        return '<section class="sec sec--wide reveal">' + idx + (head ? '<div class="sec__side sec__side--row">' + head + "</div>" : "") + '<div class="gallery">' +
          (s.items || []).map(function (it, k) { return U.fig(it.src, it.alt, it.caption, k === 0 ? "16/10" : "4/3", k === 0 ? "gallery__lead" : ""); }).join("") + "</div></section>";
      case "steps":
        return '<section class="sec sec--wide reveal">' + idx + (head ? '<div class="sec__side sec__side--row">' + head + "</div>" : "") + '<ol class="steps">' +
          (s.items || []).map(function (it, k) {
            return '<li class="step"><span class="step__n mono">' + U.pad(k + 1) + "</span>" + U.fig(it.src, it.title, "", "4/3") + '<h3 class="step__t">' + U.esc(it.title) + '</h3><p class="step__b">' + U.esc(it.body || "") + "</p></li>";
          }).join("") + "</ol></section>";
      case "demo":
        return '<section class="sec sec--wide reveal" data-demo>' + idx + (head ? '<div class="sec__side sec__side--row">' + head + "</div>" : "") +
          '<div class="demo"><canvas class="demo__canvas" aria-label="Interactive pheromone field. Drag to deposit pheromone."></canvas>' +
          '<div class="demo__ctl mono"><label>Evaporation <input type="range" min="0" max="12" value="2" data-k="evap"><output>0.02</output></label>' +
          '<label>Diffusion <input type="range" min="0" max="10" value="3" data-k="diff"><output>0.30</output></label>' +
          '<button type="button" class="btn mono" data-reset>Reset field</button></div>' +
          (s.caption ? '<p class="demo__cap mono mono--lc muted">' + U.esc(s.caption) + "</p>" : "") + "</div></section>";
      case "terminal":
        return '<section class="sec sec--text reveal"><div class="sec__side">' + idx + head + "</div><div>" + termWindow(s.title || "terminal", termLines(s.lines)) + "</div></section>";
      case "specs":
        return '<section class="sec sec--text reveal"><div class="sec__side">' + idx + head + '</div><dl class="specs mono">' + specRows(s.rows) + "</dl></section>";
    }
    return "";
  }

  function heroHtml(p) {
    var meta = '<ul class="chips mono" aria-label="Stack">' + chips(p.stack) + "</ul>";
    var lk = links(p.links);
    if (p.layout === "simulation") {
      return '<header class="hero hero--sim"><canvas class="hero__canvas" data-field="hero" aria-hidden="true"></canvas>' +
        '<div class="hero__over"><p class="mono hero__kicker">' + U.esc(p.year || "") + (p.status ? " · " + U.esc(p.status) : "") + '</p><h1 class="hero__title">' + U.esc(p.title) + "</h1>" +
        (p.tagline ? '<p class="hero__tag">' + U.esc(p.tagline) + "</p>" : "") + meta + (lk ? '<p class="hero__links">' + lk + "</p>" : "") + "</div></header>";
    }
    if (p.layout === "terminal") {
      var kv = (p.specs || []).map(function (r) { return '<div class="t-line t-out"><span class="t-key">' + U.esc(r[0]).toLowerCase() + ":</span> " + U.esc(r[1]) + "</div>"; }).join("");
      var lkt = (p.links || []).filter(function (l) { return U.safeUrl(l.url); }).map(function (l) { return '<div class="t-line t-out"><span class="t-key">' + U.esc(l.label).toLowerCase() + ':</span> <a href="' + U.esc(U.safeUrl(l.url)) + '" rel="noopener noreferrer" target="_blank">' + U.esc(l.url) + "</a></div>"; }).join("");
      return '<header class="hero hero--term">' +
        '<h1 class="hero__title">' + U.esc(p.title) + "</h1>" +
        termWindow(String(p.title).toLowerCase() + " — info",
          '<div class="t-line"><span class="t-prompt">$</span> <span class="t-cmd">' + U.esc(String(p.title).toLowerCase()) + " --about</span></div>" +
          (p.tagline ? '<div class="t-line t-out t-big">' + U.esc(p.tagline) + "</div>" : "") +
          '<div class="t-line t-out">' + U.esc(p.summary || "") + "</div><div class=\"t-gap\"></div>" +
          '<div class="t-line t-out"><span class="t-key">year:</span> ' + U.esc(p.year || "—") + '</div><div class="t-line t-out"><span class="t-key">status:</span> ' + U.esc(p.status || "—") + "</div>" +
          '<div class="t-line t-out"><span class="t-key">stack:</span> ' + U.esc((p.stack || []).join(", ")) + "</div>" + kv + lkt +
          '<div class="t-line"><span class="t-prompt">$</span> <span class="cursor" aria-hidden="true"></span></div>') + "</header>";
    }
    return '<header class="hero hero--std"><div class="hero__text"><p class="mono hero__kicker">' + U.esc(p.year || "") + (p.status ? " · " + U.esc(p.status) : "") + '</p><h1 class="hero__title">' + U.esc(p.title) + "</h1>" +
      (p.tagline ? '<p class="hero__tag">' + U.esc(p.tagline) + "</p>" : "") + meta + (lk ? '<p class="hero__links">' + lk + "</p>" : "") + "</div>" +
      '<div class="crop hero__cover">' + (p.cover ? '<img src="' + U.esc(p.cover) + '" alt="' + U.esc(p.title) + ' preview">' : '<div class="ph" role="img" aria-label="Cover placeholder"><span>cover<br>' + U.esc(p.title) + "</span></div>") + "</div></header>";
  }

  function renderProject(p, idx) {
    U.setTitle(p.title);
    var prev = projects[idx - 1], next = projects[idx + 1];
    var specs = p.layout !== "terminal" && p.specs && p.specs.length ? '<dl class="specbar mono">' + specRows(p.specs) + "</dl>" : "";
    var summary = p.layout === "terminal" ? "" : (p.summary ? '<p class="lede">' + U.esc(p.summary) + "</p>" : "");
    main.innerHTML =
      '<article class="case case--' + U.esc(p.layout || "standard") + '">' +
        '<p class="case__back mono"><a href="projects.html">← ~/projects</a> <span class="muted">/ ' + U.esc(p.slug) + "</span></p>" +
        heroHtml(p) + specs + summary +
        (p.sections || []).map(sectionHtml).join("") +
        '<nav class="pager mono" aria-label="More projects">' +
          (prev ? '<a href="#' + U.esc(prev.slug) + '"><span class="muted">← prev</span> ' + U.esc(prev.title) + "</a>" : "<span></span>") +
          (next ? '<a href="#' + U.esc(next.slug) + '">' + U.esc(next.title) + ' <span class="muted">next →</span></a>' : "<span></span>") +
        "</nav></article>";

    var hc = main.querySelector("canvas[data-field=hero]");
    if (hc) mountField(hc, { w: 192, h: 80, agents: 110 });
    main.querySelectorAll("[data-demo]").forEach(function (sec) {
      var sim = mountField(sec.querySelector("canvas"), { w: 176, h: 90, agents: 90, interactive: true });
      sec.querySelectorAll("input[type=range]").forEach(function (r) {
        function upd() { var v = +r.value / (r.dataset.k === "evap" ? 100 : 10); r.nextElementSibling.textContent = v.toFixed(2); sim.set(r.dataset.k, v); }
        r.addEventListener("input", upd); upd();
      });
      sec.querySelector("[data-reset]").addEventListener("click", function () { sim.reset(); });
    });
    U.reveal(main);
  }

  function route() {
    live.forEach(function (s) { s.stop(); }); live = [];
    var slug = decodeURIComponent(location.hash.slice(1));
    var idx = -1;
    projects.forEach(function (p, i) { if (p.slug === slug) idx = i; });
    if (idx >= 0) renderProject(projects[idx], idx); else renderIndex();
    window.scrollTo(0, 0);
    main.focus({ preventScroll: true });
  }
  window.addEventListener("hashchange", route);
  route();
})();
