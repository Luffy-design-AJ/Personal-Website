/* ==========================================================================
   COMMON — shared helpers: nav + footer, escaping, image fallbacks, markdown,
   date formatting, scroll reveal. No dependencies.
   ========================================================================== */
(function () {
  "use strict";
  document.documentElement.classList.add("js");

  var SITE = window.SITE || {};

  /* ---------- tiny helpers ---------- */
  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function slugify(s) {
    return String(s).toLowerCase().replace(/<[^>]+>/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  }
  var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  function parseDate(d) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(d || "");
    return m ? { y: +m[1], m: +m[2], d: +m[3] } : null;
  }
  function fmtDate(d) {
    var p = parseDate(d);
    return p ? (p.d + " " + MONTHS[p.m - 1] + " " + p.y) : esc(d || "");
  }
  function fmtShort(d) {
    var p = parseDate(d);
    return p ? (("0" + p.m).slice(-2) + "·" + ("0" + p.d).slice(-2)) : "";
  }
  function year(d) { var p = parseDate(d); return p ? p.y : ""; }
  function pad(n, w) { n = String(n); while (n.length < (w || 2)) n = "0" + n; return n; }
  function safeUrl(u) {
    u = String(u || "").trim();
    return /^(https?:|mailto:|\/|\.\/|\.\.\/|#|[\w\-\/]+\.[\w]+)/i.test(u) && !/^javascript:/i.test(u) ? u : "";
  }
  function isExternal(u) { return /^https?:/i.test(u); }

  /* inline italic using *asterisks* (for display text, e.g. the homepage statement) */
  function inlineItalic(s) {
    return esc(s).replace(/\*([^*]+)\*/g, "<em>$1</em>");
  }

  /* ---------- image / figure helpers ---------- */
  function fig(src, alt, caption, ratio, cls) {
    var style = ratio ? ' style="aspect-ratio:' + esc(ratio) + '"' : "";
    var inner = src
      ? '<img src="' + esc(src) + '" alt="' + esc(alt || "") + '" loading="lazy" decoding="async"' + style + ">"
      : '<div class="ph" role="img" aria-label="' + esc(alt || "Image placeholder") + '"' + style + "><span>" + esc(alt || "image") + "</span></div>";
    return '<figure class="fig ' + (cls || "") + '">' + inner +
      (caption ? '<figcaption class="mono mono--lc">' + esc(caption) + "</figcaption>" : "") + "</figure>";
  }
  /* any <img> that fails to load becomes a labelled placeholder so layouts never collapse */
  document.addEventListener("error", function (e) {
    var t = e.target;
    if (!t || t.tagName !== "IMG" || t.dataset.failed) return;
    t.dataset.failed = "1";
    var ph = document.createElement("div");
    ph.className = "ph";
    ph.setAttribute("role", "img");
    ph.setAttribute("aria-label", t.alt || "Missing image");
    var name = (t.getAttribute("src") || "").split("/").pop();
    ph.innerHTML = "<span>" + esc(t.alt || "missing image") + "<br>" + esc(name) + "</span>";
    t.replaceWith(ph);
  }, true);

  /* ---------- markdown (small, safe, enough for articles) ---------- */
  function inlineMd(s) {
    var codes = [], maths = [];
    /* stash TeX before escaping/markdown so $, _, * and < survive untouched */
    s = String(s).replace(/(\$\$[\s\S]+?\$\$|\$[^$\n]+?\$|\\\[[\s\S]+?\\\]|\\\([\s\S]+?\\\))/g, function (m) {
      maths.push(m); return "\u0001" + (maths.length - 1) + "\u0001";
    });
    s = esc(s).replace(/`([^`]+)`/g, function (_, c) { codes.push(c); return "\u0000" + (codes.length - 1) + "\u0000"; });
    s = s
      .replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, function (_, a, u) { var uu = safeUrl(u.replace(/&amp;/g, "&")); return uu ? '<img src="' + uu + '" alt="' + a + '" loading="lazy">' : ""; })
      .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, function (_, t, u) {
        var uu = safeUrl(u.replace(/&amp;/g, "&"));
        return uu ? '<a href="' + uu + '"' + (isExternal(uu) ? ' rel="noopener noreferrer" target="_blank"' : "") + ">" + t + "</a>" : t;
      })
      .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
      .replace(/(^|[^*\w])\*([^*\n]+)\*(?!\w)/g, "$1<em>$2</em>")
      .replace(/(^|[^\w])_([^_\n]+)_(?!\w)/g, "$1<em>$2</em>");
    return s
      .replace(/\u0000(\d+)\u0000/g, function (_, i) { return "<code>" + codes[+i] + "</code>"; })
      .replace(/\u0001(\d+)\u0001/g, function (_, i) { return esc(maths[+i]); });
  }

  function md(src) {
    var lines = String(src || "").replace(/\r\n?/g, "\n").replace(/^\n+|\s+$/g, "").split("\n");
    var out = [], toc = [], i = 0;
    // strip common indentation (template literals are usually indented)
    var ind = Infinity;
    lines.forEach(function (l) { if (l.trim()) { var m = /^ */.exec(l)[0].length; if (m < ind) ind = m; } });
    if (ind && ind !== Infinity) lines = lines.map(function (l) { return l.slice(Math.min(ind, /^ */.exec(l)[0].length)); });

    while (i < lines.length) {
      var line = lines[i];
      if (!line.trim()) { i++; continue; }

      var fence = /^```(\w*)\s*$/.exec(line);
      if (fence) {
        var buf = []; i++;
        while (i < lines.length && !/^```\s*$/.test(lines[i])) { buf.push(lines[i]); i++; }
        i++;
        out.push('<pre class="code"' + (fence[1] ? ' data-lang="' + esc(fence[1]) + '"' : "") + "><code>" + esc(buf.join("\n")) + "</code></pre>");
        continue;
      }
      var h = /^(#{1,3})\s+(.*)$/.exec(line);
      if (h) {
        var level = Math.max(2, h[1].length), text = h[2].trim(), id = slugify(text);
        if (level === 2) toc.push({ id: id, text: text.replace(/[*_`]/g, "") });
        out.push("<h" + level + ' id="' + id + '">' + inlineMd(text) + "</h" + level + ">");
        i++; continue;
      }
      if (/^(-{3,}|\*{3,})\s*$/.test(line)) { out.push("<hr>"); i++; continue; }
      var im = /^!\[([^\]]*)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)\s*$/.exec(line);
      if (im) { out.push(fig(safeUrl(im[2]), im[1], im[3] || "")); i++; continue; }
      if (/^>/.test(line)) {
        var q = [];
        while (i < lines.length && /^>/.test(lines[i])) { q.push(lines[i].replace(/^>\s?/, "")); i++; }
        var cite = "";
        if (q.length > 1 && /^[—–-]\s/.test(q[q.length - 1])) cite = q.pop().replace(/^[—–-]\s/, "");
        out.push("<blockquote><p>" + inlineMd(q.join(" ")) + "</p>" + (cite ? "<cite>" + inlineMd(cite) + "</cite>" : "") + "</blockquote>");
        continue;
      }
      var ul = /^\s*[-*]\s+/.test(line), ol = /^\s*\d+\.\s+/.test(line);
      if (ul || ol) {
        var re = ul ? /^\s*[-*]\s+/ : /^\s*\d+\.\s+/, items = [];
        while (i < lines.length && re.test(lines[i])) { items.push("<li>" + inlineMd(lines[i].replace(re, "")) + "</li>"); i++; }
        out.push((ul ? "<ul>" : "<ol>") + items.join("") + (ul ? "</ul>" : "</ol>"));
        continue;
      }
      var p = [];
      while (i < lines.length && lines[i].trim() && !/^(```|#{1,3}\s|>|---|\*\*\*|\s*[-*]\s|\s*\d+\.\s|!\[)/.test(lines[i])) { p.push(lines[i]); i++; }
      if (!p.length) { p.push(lines[i]); i++; }
      out.push("<p>" + inlineMd(p.join(" ")) + "</p>");
    }
    return { html: out.join("\n"), toc: toc };
  }

  function readingTime(src) {
    var words = String(src || "").trim().split(/\s+/).length;
    return Math.max(1, Math.round(words / 220)) + " min";
  }

  /* ---------- nav + footer ---------- */
  var PAGES = [
    { id: "home", label: "Home", href: "index.html" },
    { id: "writing", label: "Writing", href: "writing.html" },
    { id: "projects", label: "Projects", href: "projects.html" },
    { id: "reading", label: "Reading", href: "reading.html" }
  ];

  function chrome() {
    var page = document.body.dataset.page;
    var nav = document.getElementById("nav");
    if (nav) {
      nav.className = "nav";
      nav.innerHTML =
        '<a class="nav__brand" href="index.html" aria-label="' + esc(SITE.name || "Home") + ' — home">' + esc(SITE.brand || SITE.name || "home") + "</a>" +
        '<nav aria-label="Primary"><ul class="nav__list">' +
        PAGES.map(function (p) {
          return '<li><a class="nav__link" href="' + p.href + '"' + (p.id === page ? ' aria-current="page"' : "") + ">" + p.label + "</a></li>";
        }).join("") + "</ul></nav>";
    }
    var footer = document.getElementById("footer");
    if (footer) {
      footer.className = "footer";
      var links = (SITE.links || []).filter(function (l) { return safeUrl(l.url); });
      footer.innerHTML =
        '<div class="footer__contact"><p class="mono muted" style="margin-bottom:.6rem">Contact</p>' +
        (SITE.email ? '<a class="footer__mail" href="mailto:' + esc(SITE.email) + '">' + esc(SITE.email) + "</a>" : "") + "</div>" +
        (links.length ? '<ul class="footer__links" aria-label="Profiles">' + links.map(function (l) {
          var u = safeUrl(l.url);
          return '<li><a href="' + esc(u) + '"' + (isExternal(u) ? ' rel="noopener noreferrer" target="_blank"' : "") + ">" + esc(l.label) + " ↗</a></li>";
        }).join("") + "</ul>" : "") +
        '<p class="footer__colophon mono"><span>© ' + new Date().getFullYear() + " " + esc(SITE.name || "") + '</span><span>Set in Instrument Serif, Newsreader &amp; IBM Plex Mono</span></p>';
    }
  }

  /* ---------- scroll reveal (progressive; content is visible without JS) ---------- */
  function reveal(root) {
    var els = (root || document).querySelectorAll(".reveal:not(.in)");
    if (!("IntersectionObserver" in window) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      els.forEach(function (e) { e.classList.add("in"); }); return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.06 });
    els.forEach(function (e) { io.observe(e); });
  }

  function setTitle(t) {
    document.title = (t ? t + " — " : "") + (SITE.name || "Personal site");
  }

  function empty(msg) {
    return '<p class="empty mono mono--lc">' + msg + "</p>";
  }

  window.U = {
    esc: esc, slugify: slugify, fmtDate: fmtDate, fmtShort: fmtShort, year: year, pad: pad,
    safeUrl: safeUrl, isExternal: isExternal, inlineItalic: inlineItalic, fig: fig, md: md,
    readingTime: readingTime, reveal: reveal, setTitle: setTitle, empty: empty
  };

  chrome();
})();
