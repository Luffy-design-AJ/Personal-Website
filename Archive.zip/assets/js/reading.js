/* READING — a quiet bookshelf. Hover / focus / tap a cover to read the thought. */
(function () {
  "use strict";
  var U = window.U, S = window.SITE || {};
  var main = document.getElementById("main");
  var books = window.BOOKS || [];
  U.setTitle("Reading");

  function cover(b) {
    var label = "Cover of " + b.title;
    return b.cover
      ? '<img class="cover__img" src="' + U.esc(b.cover) + '" alt="' + U.esc(label) + '" loading="lazy" decoding="async" width="400" height="600">'
      : '<span class="cover__draw" role="img" aria-label="' + U.esc(label) + '" style="--c:' + U.esc(b.color || "#6b5a45") + '">' +
          '<span class="cover__title">' + U.esc(b.title) + '</span><span class="cover__author mono">' + U.esc(b.author || "") + "</span></span>";
  }

  main.innerHTML =
    '<div class="shelf-page">' +
      '<header class="shelf-head rise"><h1 class="shelf-title">Reading</h1>' +
      (S.readingIntro ? '<p class="shelf-intro">' + U.esc(S.readingIntro) + "</p>" : "") + "</header>" +
      (books.length
        ? '<ul class="shelf">' + books.map(function (b, i) {
            var id = "thought-" + i;
            return '<li class="book rise" style="--i:' + Math.min(i, 12) + '">' +
              '<button type="button" class="book__btn" aria-expanded="false" aria-describedby="' + id + '">' +
                '<span class="book__cover">' + cover(b) +
                  '<span class="book__thought" id="' + id + '"><span>' + (b.thought ? U.esc(b.thought) : '<span class="muted">No thoughts written yet.</span>') + "</span></span>" +
                "</span>" +
              "</button>" +
              '<p class="book__meta"><span class="book__t">' + U.esc(b.title) + '</span><span class="book__a mono">' + U.esc(b.author || "") + "</span>" +
              (b.reading ? '<span class="book__now mono"><span aria-hidden="true">●</span> reading now</span>' : "") + "</p></li>";
          }).join("") + "</ul>"
        : U.empty("The shelf is empty — add books in content/books.js.")) +
    "</div>";

  /* tap / keyboard toggle (hover is pure CSS). Only one open at a time. */
  var btns = main.querySelectorAll(".book__btn");
  btns.forEach(function (b) {
    b.addEventListener("click", function () {
      var open = b.getAttribute("aria-expanded") === "true";
      btns.forEach(function (x) { x.setAttribute("aria-expanded", "false"); });
      b.setAttribute("aria-expanded", open ? "false" : "true");
    });
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") btns.forEach(function (x) { x.setAttribute("aria-expanded", "false"); });
  });
})();
