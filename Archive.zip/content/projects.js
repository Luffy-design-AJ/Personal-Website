/* ==========================================================================
   PROJECTS  —  one object per project. Each gets a tile in the archive and its own
   case-study page (projects.html#slug).

   Top-level fields
     slug        unique, lowercase-with-dashes
     title       project name
     layout      picks the visual treatment (see below):
                   "simulation"  dark canvas hero, for things with a live/visual system (games, sims)
                   "terminal"    terminal-window treatment, for CLIs and tools
                   "standard"    large preview + spec sheet, for everything else
     year        "2026"
     tagline     one line
     summary     two or three sentences
     type       ["Python", "Rust", ...]   shown as technical metadata
     specs       [["Label", "value"], ...] small spec table, e.g. [["Engine","custom"],["Lines","~4k"]]
     links       [{ label: "Source", url: "https://github.com/..." }, { label: "Demo", url: "..." }]
     cover       image for the tile + header, e.g. "assets/img/projects/swarm-cover.png" ("" = placeholder)
     featured    true = also shown in "Selected projects" on the homepage
     draft       true = hidden everywhere
     sections    the case study body, a list of blocks (types below)

   Section block types
     { type: "text",     heading: "Overview", body: "Markdown…" }
     { type: "figure",   src: "assets/img/projects/x.png", alt: "…", caption: "Fig. 1 — …" }
     { type: "video",    src: "assets/video/x.mp4", poster: "assets/img/projects/x.png", caption: "…" }
     { type: "gallery",  items: [{ src: "…", alt: "…", caption: "…" }, …] }
     { type: "steps",    heading: "How it works", items: [{ title: "…", body: "…", src: "…" }, …] }
     { type: "demo",     demo: "field", heading: "Try it", caption: "…" }     ← interactive pheromone field
     { type: "terminal", heading: "Usage", title: "palate", lines: [ { cmd: "palate add ramen" }, { out: "added." } ] }
     { type: "specs",    heading: "Details", rows: [["Label","value"], …] }

   Blocks render in the order you list them. Mix and match; leave out what you don't need.
   ========================================================================== */

window.PROJECTS = [

  {
    slug: "swarm",
    title: "Swarm",
    layout: "simulation",
    year: "2026",
    status: "in progress",
    tagline: "[placeholder] One line describing the game.",
    summary: "[placeholder] Two or three sentences: what the project is, how it plays, and what's interesting about how it works.",
    type: ["Language", "Library"],                               // [placeholder]
    specs: [["Genre", "[placeholder]"], ["Engine", "[placeholder]"], ["Status", "[placeholder]"]],
    links: [
      { label: "Source", url: "https://github.com/your-username/swarm" }   // [placeholder]
    ],
    cover: "",
    featured: true,
    draft: false,
    sections: [
      { type: "text", heading: "Overview", body: "[placeholder] Explain the project in plain language first. What is it, who is it for, why did you make it?" },
      { type: "demo", demo: "field", heading: "The field, live", caption: "Click and drag to lay pheromone. The small agents climb the gradient. Use the sliders to change how fast it evaporates and spreads. [Placeholder demo — swap it for your own, or delete this block.]" },
      { type: "steps", heading: "How it works", items: [
        { title: "[placeholder] Step one",   body: "Describe the first mechanic. Add a screenshot or diagram with the src field.", src: "" },
        { title: "[placeholder] Step two",   body: "Describe the second mechanic.", src: "" },
        { title: "[placeholder] Step three", body: "Describe the third mechanic.", src: "" }
      ]},
      { type: "video", src: "", poster: "", caption: "Gameplay footage — [placeholder]" },
      { type: "text", heading: "What was hard", body: "[placeholder] The interesting technical or mathematical problem, written out." }
    ]
  },

  {
    slug: "palate",
    title: "Palate",
    layout: "terminal",
    year: "2026",
    status: "shipped",
    tagline: "[placeholder] One line describing the tool.",
    summary: "[placeholder] Two or three sentences: what the command-line tool does and how it models preferences.",
    stack: ["Language"],                                            // [placeholder]
    specs: [["Interface", "CLI"], ["Install", "[placeholder]"], ["License", "[placeholder]"]],
    links: [
      { label: "Source", url: "https://github.com/your-username/palate" }   // [placeholder]
    ],
    cover: "",
    featured: true,
    draft: false,
    sections: [
      { type: "text", heading: "What it is", body: "[placeholder] Describe the tool and the problem it solves." },
      { type: "terminal", heading: "Usage", title: "palate", lines: [
        { cmd: "palate --help" },
        { out: "[placeholder] paste real output from your tool here" },
        { cmd: "palate add \"something\"" },
        { out: "[placeholder]" }
      ]},
      { type: "text", heading: "How it models taste", body: "[placeholder] Explain the model. Add a figure or a diagram below if it helps." },
      { type: "figure", src: "", alt: "", caption: "Fig. 1 — [placeholder] a diagram of the model" }
    ]
  },

  {
    slug: "project-three",
    title: "[placeholder] Project three",
    layout: "standard",
    year: "2025",
    status: "archived",
    tagline: "[placeholder] One line.",
    summary: "[placeholder] Two or three sentences about this project.",
    stack: ["Language"],
    specs: [["Type", "[placeholder]"], ["Role", "[placeholder]"]],
    links: [{ label: "Source", url: "" }],
    cover: "",
    featured: true,
    draft: false,
    sections: [
      { type: "text", heading: "Overview", body: "[placeholder] What it is and why it exists." },
      { type: "gallery", items: [
        { src: "", alt: "", caption: "[placeholder] screenshot" },
        { src: "", alt: "", caption: "[placeholder] screenshot" },
        { src: "", alt: "", caption: "[placeholder] screenshot" }
      ]}
    ]
  }

];
