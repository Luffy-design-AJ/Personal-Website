/* ==========================================================================
   READING  —  one object per book. Order here = order on the shelf (first = top-left).

   Fields
     title    book title
     author   author name
     cover    image path, e.g. "assets/img/books/my-book.jpg" (cover images are ~2:3).
              Leave "" and a typographic cover is drawn for you.
     color    only used when there's no cover image: any CSS colour for the drawn cover
     thought  your short reflection. Revealed when someone hovers / focuses / taps the cover.
              Keep it to a few sentences, in your own voice.
     reading  true = tiny "reading now" mark on the cover (optional)

   No ratings, no stats — on purpose.
   ========================================================================== */

window.BOOKS = [
  { title: "[placeholder] Book title one",   author: "Author Name", cover: "", color: "#7b5a3c", thought: "[placeholder] A short personal reflection on this book: what stayed with you, what you disagreed with.", reading: true },
  { title: "[placeholder] Book title two",   author: "Author Name", cover: "", color: "#44564a", thought: "[placeholder] Another reflection." },
  { title: "[placeholder] Book title three", author: "Author Name", cover: "", color: "#8a3d2e", thought: "[placeholder] Another reflection." },
  { title: "[placeholder] Book title four",  author: "Author Name", cover: "", color: "#2f3d52", thought: "[placeholder] Another reflection." },
  { title: "[placeholder] Book title five",  author: "Author Name", cover: "", color: "#a08752", thought: "[placeholder] Another reflection." },
  { title: "[placeholder] Book title six",   author: "Author Name", cover: "", color: "#5a3f4d", thought: "[placeholder] Another reflection." }
];
