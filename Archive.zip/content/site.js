/* ==========================================================================
   SITE CONTENT  —  edit this file to change the homepage, footer and nav.
   Everything marked [placeholder] is dummy text: replace it with your own.
   Leave a field as "" (or [] for lists) and that piece simply disappears.
   ========================================================================== */

window.SITE = {

  /* ---- identity ---- */
  name: "Aarit Jhindal",                 // [placeholder] shown as the big typographic title on the homepage (split on spaces)
  brand: "Luffy_AJ",                 // [placeholder] short mark in the top-left of the nav
  email: "aarit120jhindal@gmail.com",          // [placeholder] used in the footer + contact section
  location: "Thane, India",         // [placeholder] tiny metadata label on the homepage
  updated: "November 2026",          // shown as "last updated" on the homepage

  /* ---- profiles (footer + contact). Add / remove freely. ---- */
  links: [
    { label: "GitHub",   url: "https://github.com/Luffy-design-AJ" },          // [placeholder]
    { label: "Instagram", url: "https://www.instagram.com/aardor_km/" }, // [placeholder]
        { label: "CV (PDF)", url: "/Users/aaritjhindal/Documents/Certificates/Papers/Resume_AJ.pdf" }                                           // e.g. "assets/cv.pdf"
  ],

  /* ---- page intros (one or two lines, shown at the top of each page) ---- */
  writingIntro:  "",
  projectsIntro: "",
  readingIntro:  "",

  /* ---- HOME ---- */
  home: {
    
    // 2–3 sentence introduction in your own voice.
    intro: "A high school student from India with an unusual blend of interests and a really stubborn curiosity",

    // a larger statement about the things you explore and make. Appears set big, mid-page.
    // Wrap a phrase in *asterisks* to set it in italic.
    statement: "I like taking things apart, finding unexpected connections, and building things just to see if I can.",

    // optional portrait / photo. Put the file in assets/img/ and set the path, e.g. "assets/img/me.jpg".
    portrait: "/Users/aaritjhindal/Documents/personal-site/content/Image.jpeg",
    

    // small marginal notes scattered around the top of the homepage. 0–3 items.
    marginalia: [
      
      
    ]
  },

  /* ---- CV / EXPERIENCE (homepage). Newest first. ---- */
  cv: [
 { years: "2018- now",  title: "Swimming", place: "Starfish Sports Foundation, Life Saving Association of Sri Lanka", note: "Worlds Longest Open Water Swimming Competition, Finswimming Nationals[2024,2025], Total 176km Competitive Open Water Swims" },
{ years: "2026",  title: "RP2", place: "Ross Mathematics Foundation", note: "Combinatorial Game Theory" },
{ years: "2024 – now",  title: "Math Circle India", place: "ICTS Bengaluru", note: "" },
{ years: "2025 – now",  title: "Math Circle Mumbai", place: "TIFR- Prof. Amitava Bhattacharya", note: "" },

{ years: "2025 – now",  title: "A Levels", place: "CP Goenka International School Thane", note: "Physics, Chemistry, Math, Further Math, Business, EGP" },
   
    { years: "2023 – 2025", title: "IGCSE", place: "CP Goenka International School Thane", note: "Physics, Chemistry, Math, Bio, French, FLE, Art" },
{ years: "2025",  title: "p-adic Research", place: "Cheenta Summer Research Program", note: "First Principle Approach to the Calculus of p-adic numbers" },
    
  ]
};
