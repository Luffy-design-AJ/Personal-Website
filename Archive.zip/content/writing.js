/* ==========================================================================
   WRITING  —  one object per article. Newest order is handled automatically (by date).

   To add an article: copy one block, change the fields, write the body in Markdown
   inside the backticks. That's it — it appears in the archive and gets its own page.

   Fields
     slug         unique, lowercase-with-dashes (becomes the URL: writing.html#my-slug)
     title        article title
     date         "YYYY-MM-DD"
     category     one short word: "maths", "physics", "code", "games", "notes"…
     status       optional digital-garden stage: "seedling" | "budding" | "evergreen"
     description  one or two sentences shown in the archive
     featured     true = also shown in "Selected writing" on the homepage
     draft        true = hidden everywhere (handy while you write)
     body         Markdown (see the first article for everything that's supported)

   Images:  put files in assets/img/writing/ and use  ![alt text](assets/img/writing/file.png "optional caption")

   Imported from aaritjhindalinfosponge.blogspot.com. Backslashes inside the
   bodies are doubled because the bodies are template literals (TeX needs this).
   ========================================================================== */

window.WRITING = [
  {
    slug: "all-notes-on-the-swarm-game",
    title: "All notes on the Swarm Game",
    date: "2026-08-12",
    category: "games",
    description: "Everything I've written about Swarm — the idea, the pheromone fields, the failed prototypes and where the game is going.",
    featured: false,
    draft: false,
    body: `
### Designing Emergent Behaviour Through Pheromone Fields

### The idea

I have always been fascinated by the idea of designing a game, but I wanted to make something more than a game with interesting mechanics. I wanted to create a system that could **surprise me**.

Throughout school, and often even in college, learning rarely feels exploratory. We are taught scientific facts, but not always the experience of discovering them. If we were stranded in an unknown star system with no memory—yes, a *Project Hail Mary* reference—most of us would have little idea how to determine where we were.

I wanted to capture that feeling of discovery in a game without making an explicitly educational game.

Around the same time, I became increasingly interested in random and emergent systems through Math Circle, and I was inspired by Richard Feynman's experiments with ants. That led to a simple question:

**Could I build a system whose behaviour I could influence without directly controlling it?**

That question became Swarm.

---

## 1. The original experiment

The first version was not a combat game.

It was an experiment in **emergence**.

Instead of controlling individual ants, I wanted the player to manipulate the environment in which the ants operated. The player could place chemical signals, but the ants themselves followed a set of simple rules.

The interesting part was that the player could never explicitly tell an ant:

> "Go there."

Instead, the player had to create the conditions under which the ant would *choose* to go there.

This distinction became the central design principle of the entire project.

### The player controls the environment, not the agents.

I represented pheromones as discrete **scalar fields** defined over a grid. Every cell contained information about the strength of different chemical signals.

The original system primarily used three types of pheromone:

### Trail pheromone

This was the weakest influence. Ants could use it to retrace paths they had already explored.

### Player pheromone

This was placed by the player. Rather than specifying a destination, it created a gradient that influenced ant movement.

### Home pheromone

Returning ants deposited this pheromone as they travelled back toward the nest. Over time, successful routes became reinforced.

This produced a feedback loop:

**ant finds food → returns home → reinforces path → other ants follow it → path becomes stronger → more ants use it.**

The player wasn't programming a highway.

The highway **emerged from the system**.

---

## 2. Building the fields

The pheromone system was built around discrete scalar fields rather than simply storing paths.

Each field represented a value at every cell in the environment.

The ants sampled these fields and used their local gradients to influence movement.

The fields also changed over time.

Signals:

- diffused through neighbouring cells
- decayed
- interacted with other signals
- were reinforced by new deposits

This meant that the game wasn't simply calculating:

> "Where should this ant go?"

It was continuously evolving a physical-ish environment and allowing the ant simulation to react to it.

One of the things I particularly liked was that the system was **not deterministic in the way a traditional pathfinding system is**. Exploration, noise, decay and competing signals meant that identical high-level conditions could produce different local behaviour.

That unpredictability was not a bug.

It was the point.

---

## 3. The first thing I learned: emergence is fragile

The system initially looked promising, but it was extremely sensitive to the relative strengths of its fields.

If one pheromone became too strong, it dominated everything else.

If decay was too fast, trails disappeared before they could become useful.

If exploration was too low, ants became excessively committed to existing paths.

If noise was too high, the colony stopped behaving coherently.

This became one of the most interesting parts of the project.

I wasn't simply balancing game variables.

I was trying to find a region in parameter space where **simple local rules produced interesting global behaviour**.

The goal wasn't maximum efficiency.

It was a system that was:

- predictable enough to learn,
- unpredictable enough to explore,
- responsive enough to manipulate,
- autonomous enough to feel alive.

That balance became the real game mechanic.

---

## 4. From experiment to game

Eventually I wanted to push the system further.

The original prototype was essentially a real-time puzzle about sculpting emergent behaviour through chemical fields.

I started asking:

**What if the same principle became the basis of combat?**

That led to the current Swarm prototype, which evolved into a combat roguelite inspired by games such as *Hades*.

But I deliberately refused to make it a conventional hack-and-slash game.

The player is intentionally weak.

They cannot simply attack an enemy themselves.

Instead, the player influences the swarm.

This preserved the original idea:

> **The player does not command the swarm directly. They manipulate the ecosystem and allow order to emerge.**

---

## 5. Turning pheromones into a combat system

I developed several pheromone abilities that give the player increasingly sophisticated ways to influence the swarm.

### Passive Nest Pheromone

The player constantly emits a weak nest pheromone.

Nearby ants are gently attracted toward the player, allowing the player to reposition the swarm without explicitly commanding it.

### Hunt Pheromone

The player can create stronger directional pheromone gradients that guide ants toward enemies.

I experimented with several behaviours:

**Direct Hunt**

The swarm moves directly toward the selected target.

**Looping Hunt**

The pheromone creates a route that sends ants toward the target and then back around, allowing the swarm to repeatedly engage.

**Multiple-Target Hunt**

The field can coordinate the swarm across multiple targets.

**Bounce Hunt**

The signal jumps from one target to another, allowing the swarm to chain between enemies.

The important part is that these aren't commands like:

> "Ant #12 attack Enemy #3."

They are **fields**.

The ants still make their own local decisions.

---

## 6. Manipulating the swarm without controlling it

I also added abilities that don't tell the swarm where to go at all.

### Scatter Pheromone

Disperses nearby ants.

This lets the player break up concentrations when enemies are about to attack.

### Amplified Nest Pheromone

A stronger version of the normal nest signal that rapidly attracts ants toward the player.

### Localized Scatter Pulse

Creates a strong scattering field around the player, immediately forcing the swarm to spread outward.

### Hide Pheromone

Temporarily conceals ants from enemies.

These abilities created an interesting tension.

The optimal strategy isn't simply:

> **Get as many ants together as possible.**

Sometimes concentration is powerful.

Sometimes concentration is exactly what gets the swarm destroyed.

The player therefore has to reason about the **state of the entire system**, rather than just the position of an individual character.

---

## 7. Designing enemies around the system

Once the swarm became the core mechanic, I didn't want enemies to simply have different amounts of health or damage.

I designed enemies specifically to attack **different weaknesses in the swarm system**.

### Assassin — attacks the player

The Assassin prioritizes the player instead of the swarm.

It forces the player to use the swarm defensively while simultaneously managing their own movement.

The problem it creates is:

**Can I manipulate the swarm while protecting myself?**

---

### Predator — attacks concentration

The Predator searches for dense clusters of swarm units.

When it detects one, it enters a charge state and attacks the cluster.

This creates a direct conflict with the player's natural instinct to gather the swarm.

The player must alternate between:

**gather → attack → scatter → reposition → gather again.**

---

### Firewall — attacks pheromone reliability

The Firewall is surrounded by a pheromone distortion field.

Nearby pheromones become weaker or distorted.

This means the player enters an area where the very mechanism they normally rely on becomes unreliable.

Instead of simply fighting a stronger enemy, the player is fighting a **change in the rules of the system**.

---

### Parasite — attacks the information network

The Parasite infects swarm units.

Infected ants emit incorrect pheromone signals, and the infection can spread.

This is particularly interesting because pheromones are effectively the swarm's communication network.

The enemy doesn't merely damage the ants.

It **corrupts the information that the ants use to coordinate**.

---

### Collector — attacks attention

The Collector stays at range and deploys collection pods that capture nearby swarm units.

Destroying the pod releases them.

This introduces a secondary objective and forces the player to divide attention between the main enemy and the infrastructure threatening the swarm.

---

### Pheromone Flood Mine — attacks signal clarity

The Flood Mine releases a large pheromone burst when triggered.

Instead of directly damaging the player, it changes the environment the swarm is interpreting.

It effectively injects noise into the system.

---

### Pheromone Erasure Mine — attacks infrastructure

The Erasure Mine removes pheromones within an area.

This is the opposite problem.

The Flood Mine gives the swarm too much information.

The Erasure Mine removes the information the swarm depends on.

Together they create two different ways of disrupting the same underlying system.

---

### Inverter — attacks the player's own decision-making

The Inverter temporarily reverses the player's pheromone controls.

Attack commands become Scatter commands.

Scatter commands become Attack commands.

This is probably the most direct expression of the game's philosophy.

The enemy isn't simply making the swarm weaker.

It changes the relationship between **the player's intention and the system's response**.

---

## 8. The technical model

Underneath the game, the core simulation is still based on the original field system.

The Godot implementation re-created the original JavaScript scalar-field model using packed floating-point arrays.

The fields use diffusion and decay to preserve gradients rather than immediately flattening them.

Different decay constants are used for different pheromone types, allowing signals to have different temporal behaviours.

For example, some signals need to persist long enough to establish a route, while others should disappear rapidly so that they function more like temporary commands.

The simulation is also designed to be independent of frame rate, with time-scaled updates rather than simply changing behaviour depending on how quickly the computer happens to render frames.

---

## 9. From scalar fields to directional behaviour

One of the biggest technical challenges was translating the scalar field into actual movement.

A scalar field tells an ant:

> **"How strong is the signal here?"**

But the ant needs to determine:

> **"Which direction should I move?"**

The solution was to use the local gradient of the field.

The ant samples neighbouring cells and derives the direction in which the pheromone signal changes.

That gradient becomes an influence on movement.

But I didn't want ants to behave like perfect gradient-following particles.

Realistic-looking swarm behaviour needed imperfections.

So the movement model includes things such as:

- directional continuity
- random noise
- exploration
- homeward bias
- multiple competing pheromone influences

The result is not a clean shortest-path algorithm.

It is a noisy dynamical system.

And that distinction is what makes the swarm feel alive.

---

## 10. The loop that emerged

One of the most satisfying behaviours was the emergence of a self-reinforcing loop.

A forager discovers food.

It returns toward the nest.

While returning, it reinforces the home pheromone.

Other ants detect the resulting gradient.

They follow the route.

Those ants then reinforce the route further.

Eventually, the colony develops an efficient **source-to-nest highway** without ever being told to construct one.

The system creates its own infrastructure.

That was the moment the original idea really worked.

I wasn't watching an animation of ants behaving like ants.

I was watching a set of simple rules produce behaviour that I had not explicitly programmed.

---

## 11. What went wrong

The project also taught me that making emergent systems is much harder than simply making complicated systems.

At one point, the implementation became much more computationally expensive after directional/vector-field logic was introduced.

Instead of one shared representation of the environment, the system began creating unnecessary combinations of fields.

With many ants and many fields, the computation grew rapidly.

More importantly, the change damaged something more important than performance:

**the emergent behaviour itself.**

The original system felt organic because the ants were responding to shared environmental information.

The new implementation made the behaviour too explicitly engineered.

It was faster to reason about locally, but less interesting globally.

That forced me to step back and reconsider what I was actually optimizing for.

I wasn't trying to create the most sophisticated AI.

I was trying to create the conditions for **unexpected collective behaviour**.

That distinction changed how I approached the entire project.

---

## 12. Why I kept building it

The most interesting part of Swarm isn't that I managed to make ants follow pheromones.

It's that the project changed the way I think about control.

Traditional game design often asks:

> **What should the character do?**

Swarm asks a different question:

> **What conditions should I create so that the character does what I want?**

That idea connects the game's mechanics to the way many real systems behave.

A colony doesn't need a central commander.

A traffic system doesn't require one person directing every car.

A market doesn't require someone telling every participant what to do.

Complex behaviour can emerge from relatively simple local interactions.

I wanted to make that phenomenon something the player could **feel** rather than simply read about.

---

## 13. What I am still trying to solve

The project is far from finished.

The biggest challenge is still the interaction between the different fields.

If one signal dominates too much, the swarm becomes predictable.

If the fields are too weak, the player loses influence.

If the system is too chaotic, the player can't understand why something happened.

The ideal system sits somewhere between those extremes:

**I should understand enough to form a hypothesis, but never enough to know exactly what every ant will do.**

That is the feeling I am still trying to achieve.

Because ultimately, I don't want Swarm to teach the player about emergence.

I want the player to **experience it**.

---

## The central idea

Swarm started with ants.

It became a game about pheromones.

Then it became a game about combat.

But underneath all of those layers, the idea has stayed the same:

> **I don't want to tell a system what to do. I want to understand it well enough to create the conditions under which it can surprise me.**

That is what I was trying to build.

And, in a strange way, that is also what made the project fun to make.
    `
  },

  {
    slug: "updates-on-the-swarm-game",
    title: "Updates on the Swarm Game",
    date: "2026-07-02",
    category: "games",
    description: "A design log on turning Swarm from a pheromone puzzle into a combat roguelite where the player influences an ecosystem instead of commanding it.",
    featured: false,
    draft: false,
    body: `
Swarm began as a real-time puzzle game about sculpting emergent behaviour through chemical fields. Over time, the project evolved into a combat roguelite inspired by games like *Hades*, but its central idea never changed:

The player does not command the swarm directly; they manipulate an ecosystem and allow order to emerge.

For this reason, I deliberately avoided traditional hack-and-slash combat.

Instead, the playable character is intentionally weak and cannot deal damage directly. The player's role is to influence the swarm indirectly through pheromones:

- **Passive Nest Pheromone:** The character constantly emits a weak nest pheromone that nearby ants gently follow.
- **Hunt Pheromone:** The player can cast directional hunt pheromones that act as strong gradient fields, guiding the swarm toward enemies. Different casts include:
- Direct Hunt
- Looping Hunt
- Multiple-Target Hunt
- Bounce Hunt, where the signal jumps from one target to another.
- **Scatter Pheromone:** Disperses nearby ants, allowing the swarm to avoid incoming attacks or reposition quickly.
- **Amplified Nest Pheromone:** A stronger version of the nest pheromone that rapidly attracts ants toward the player.
- **Localized Scatter Pulse:** Emits a strong scattering signal around the player, instantly spreading out the swarm.
- **Hide Pheromone:** Temporarily conceals ants from enemies.

Despite these abilities, the swarm is never under direct control. The ants still obey the underlying ant simulation and pheromone-field mechanics from the original concept. The player cannot issue commands in the traditional sense; they can only influence the environment and allow complex behaviours to emerge from simple rules.

I also designed several enemies that specifically challenge different aspects of swarm control.

### Enemies:

### Asassin

Description:  Fast enemy that prioritizes attacking the player over swarm units.
Behavior:

- Targets player.
- Ignores swarm when possible.
- Re-targets player after knockback/distraction.

Purpose:  Forces player movement and defensive swarm usage.

### Predator

Description:  Anti-swarm enemy that punishes large concentrations of swarm units.
Behavior:

- Searches for dense swarm clusters.
- Enters charge state when a cluster is detected.
- Charges through the cluster, damaging swarm units.

Purpose:  Encourages alternating between gathering and scattering the swarm.

### Firewall

Description:  Heavy enemy surrounded by a pheromone distortion field.
Behavior:

- Slow movement.
- High health.
- Nearby pheromones are weakened or distorted.
- Swarm response becomes less reliable within the field.

Purpose:  Creates areas where swarm control is difficult.

### Parasite

Description:  Enemy that infects swarm units.
Behavior:

- Infects nearby swarm units.
- Infected units emit incorrect pheromone signals.
- Infection can spread to nearby swarm units.

Purpose:  Disrupts swarm behavior and creates confusion.

### Collector

Description:  Fragile ranged enemy that deploys collection pods.
Behavior:

- Stays at range.
- Throws collection pods.
- Pods capture nearby swarm units over time.
- Destroying the pod releases captured units.

Purpose:  Creates secondary targets and punishes inattention.

### Pheromone Flood Mine

Description:  Mine that releases a large pheromone burst when triggered.
Behavior:

- Activates when approached or attacked.
- Creates a temporary pheromone field.

Purpose:  Disrupts swarm positioning and control.

### Pheromone Erasure Mine

Description:  Mine that removes pheromones in an area.
Behavior:

- Activates when approached or attacked.
- Deletes pheromone fields within its radius.

Purpose:  Destroys pheromone infrastructure and pathways.

### Inverter

Description:  Enemy that temporarily reverses player pheromone controls.
Behavior:

- Applies infection/status effect to player.
- Attack commands become Scatter commands.
- Scatter commands become Attack commands.
- Effect lasts for a limited duration.

Purpose:  Disrupts player execution and decision making.
    `
  },

  {
    slug: "ant-game-v1",
    title: "Ant Game v1",
    date: "2026-05-04",
    category: "games",
    status: "evergreen",
    description: "The first playable version of the ant game: placing pheromones, watching a colony find food, and trying to make emergent behaviour happen on purpose.",
    featured: false,
    draft: false,
    body: `
[▶ Play Ant Game](https://luffy-aj.itch.io/ant-game-v2)

What is this game, and why did I create it?

I have always been fascinated by the idea of designing a game and am constantly looking for interesting concepts to explore. This particular idea emerged from a simple thought: throughout school, and often even in college, learning rarely feels exploratory or driven by discovery. We are taught scientific facts, but not always the love of science itself. If we were stranded in an unknown star system with no memory—yes, a *Project Hail Mary* reference—most of us would have little idea how to determine where we were.

I wanted to create something that captures this sense of discovery without becoming an explicitly educational game. Around the same time, I had become deeply interested in random systems through Math Circle sessions and was inspired by the joy that Richard Feynman described in his amateur ant experiments. Combining these ideas led me to an ant-based game.

In this game, the player does not control the ants directly. Instead, they manipulate the environment by placing chemicals and influencing the conditions under which the colony operates. The challenge lies in setting up the system so that the desired behaviour emerges naturally from the interactions of many simple agents.

To model pheromones, I used discrete scalar fields defined on a grid. There are three primary pheromones. The first is the trail pheromone, which exerts the weakest influence and is mainly used by ants to retrace their paths. The second is the player pheromone, placed by the player to create gradient fields that guide the ants' movement. The third is the home pheromone, released by ants returning to the nest, reinforcing efficient source-to-nest highways. Moreover, the various toggles in the 'dev mode' such as exploration rate, noise, decay, etc. help to really experiment with the emergent system.

The ants respond to all of these fields with varying strengths, while the signals themselves decay over time. There are still several issues with the mechanics—the interplay between the different field strengths does not yet feel entirely correct—but the behaviour is beginning to appear surprisingly organic, which is precisely the effect I hoped to achieve.
    `
  },

  {
    slug: "into-the-wild-my-thoughts",
    title: "Into the Wild: My thoughts",
    date: "2026-04-27",
    category: "books",
    status: "evergreen",
    description: "What Into the Wild left me thinking about: purpose, recognition, and whether the drive survives without a scoreboard.",
    featured: true,
    draft: false,
    body: `
Getting back into reading, this book shook me. Most people have brash opinions about it: Chris’s quest was noble and romantic or Chris was a selfish fool. However it went deeper than that for me. It was not a story of the romanticised throwing away your possessions and running off into the wild. That is not the innate call of humans. Rather his was a story of thirst to experience meaning and greatness. Disillusioned by the systems to achieve anything in the social world he left it. He saw it for the shallow, repetitive machine it was and he left. It made me think of why I have the goals that I do. What is life’s purpose. DNFing in a swimming competition made this book hit that much harder as I was in the emotive state: without any recognition or certificates would I still have the drive to swim. This echoed into other aspects like my interests in entrepreneurship, physics, mathematics.
    `
  },

  {
    slug: "linear-orderings-the-architecture-underneath-the-numbers",
    title: "Linear Orderings: The Architecture Underneath the Numbers [Linear Orderings Part 2]",
    date: "2026-04-19",
    category: "maths",
    status: "evergreen",
    description: "Part two of Linear Orderings: why the number line is a line, and the order structures hiding underneath the numbers.",
    featured: false,
    draft: false,
    body: `
You've spent your whole life using the number line, and you've probably never thought to ask: what exactly makes it a line? It's not the individual numbers — it's the relationship between them. The fact that $3 < 5 < 7$, that between any two rationals there is another, that the integers have gaps. These are not properties of the numbers themselves but of the ordering structure they come equipped with.

The study of these ordering structures — independently of what the elements actually are — is order theory. And it is one of the most beautiful corners of mathematics I have come across.

A linear ordering on a set $L$ is a relation $<$ satisfying:

Transitivity: if $x < y$ and $y < z$, then $x < z$.
Totality: for any distinct $x, y \\in L$, either $x < y$ or $y < x$.
Irreflexivity: $x \\not< x$ for all $x$.

Think of it as a ranking of elements on a line — everyone has a place, no two people share a place (unless they're the same person), and position respects transitivity. Simple rules, but the variety of structures they generate is staggering.

### The Standard Orderings

The natural numbers $(\\mathbb{N}, <)$: The ordering $0 < 1 < 2 < 3 < \\cdots$ satisfies all three axioms trivially. Transitivity: clear from arithmetic. Totality: given any two natural numbers, one is smaller. Irreflexivity: nothing is less than itself.

The integers $(\\mathbb{Z}, <)$: The ordering $\\cdots < -2 < -1 < 0 < 1 < 2 < \\cdots$ similarly satisfies all three. The key difference from $\\mathbb{N}$ is that there is no smallest element — you can always go further left.

The rationals $(\\mathbb{Q}, <)$: The standard ordering on $\\mathbb{Q}$ is also a linear ordering. But $\\mathbb{Q}$ has an additional property that neither $\\mathbb{N}$ nor $\\mathbb{Z}$ has: density. Between any two rationals $p < q$, there exists another rational $\\frac{p+q}{2}$. There are no gaps.

All three are genuine linear orderings. $\\checkmark$

### Infinitely Many Rankings on $\\mathbb{N}$

Now here is where things get fun. The elements of $\\mathbb{N}$ are fixed — they're just $0, 1, 2, 3, \\ldots$ — but we are free to rearrange them in whatever order we like, as long as we maintain a linear ordering. Here are some examples:

\\[
\\underbrace{0 < 1 < 2 < 3 < \\cdots}_{standard}
\\]
\\[
1 < 2 < 3 < \\cdots < 0 \\quad
\\]
\\[
2 < 3 < 4 < \\cdots < 0 < 1 \\quad
\\]
\\[
3 < 4 < 5 < \\cdots < 0 < 1 < 2 \\quad
\\]

In general, for any $k \\in \\mathbb{N}$, consider the ordering where $k, k+1, k+2, \\ldots$ come first in their natural order, followed by $0, 1, \\ldots, k-1$ in their natural order. These are all valid linear orderings on $\\mathbb{N}$, and they are all different for different values of $k$. So yes, there are infinitely many rankings on $\\mathbb{N}$.

### Infinitely Many Non-Isomorphic Rankings

This is the more subtle question. Two linear orderings are isomorphic if you can relabel the elements of one to get the other — more precisely, if there's a bijection $f: L_1 \\to L_2$ that preserves the ordering: $x <_1 y \\iff f(x) <_2 f(y)$.

You may think however if I can just relabel any element then all orderings would be isomorphic right? Just change the values and you have a new ordering! However, look at \\[1 < 2 < 3 < \\cdots < 0 \\] This can be written as 1 is in 0s place (1 maps to 0), 2 maps to 1, 3 maps to 2, etc. But what does 0 map to? n maps to n-1 and \\(0-1 = -1\\) however this is a re-ordering of natural numbers so we do not have negatives. We may be tempted to say that 0 maps to infinity however just as the new patron of the Hilbert hotel couldn't walk to infinity infinity is not a tangible mapping for any value.

![One does not simply walk to infinity](assets/img/writing/linear-orderings-2-meme.jpg)

It just takes the form of \\(\\cdots\\). Thus,
\\[
1 < 2 < 3 < \\cdots < 0
\\]
is a fundamentally different structure to
\\[
0<1 < 2 < 3 < \\cdots
\\]
The way I got intuition think of isomorphism as \`\`same form'' The orderings $1 < 2 < 3$ and $a < b < c$ are isomorphic even though they use different symbols — their structure is identical. For the non isomorphic orderings like the re-orderings of the natural numbers, we use the same shape intuition. Suppose you're holding an infinitely long stick. The stick is such that as you look to infinity the stick appears transparent. Of course, as you approach larger numbers the opacity increases and the more larger numbers consequently become the translucent ones. This is an analogue of the \\(
0<1 < 2 < 3 < \\cdots
\\) ordering. Now, imagine that while far into the horizon where the rod is already transparent at infinity there is a \\(100\\%\\) opaque block. You can never reach it but it is opaque next to the almost transparent infinity. This is the 0 at the end of the \\(\\cdots\\). This is similar to having a lightsaber that is capped at the end (the integers are then like Darth Maul's famous double bladed lightsaber).

Now, can we find infinitely many rankings on $\\mathbb{N}$ with genuinely different shapes? Yes! Consider the following rankings.
a) All the even numbers followed by all the odd numbers:
\\[0<2<4<6<8<10<\\cdots<1<3<5<7<9<11<\\cdots\\]
b) All the \\(n \\equiv0 \\;mod(3)\\) followed by \\(n \\equiv1 \\;mod(3)\\) followed by the \\(n \\equiv2 \\;mod(3)\\):
\\[0<3<6<9<12<15<\\cdots<1<4<7<10<13<16<\\cdots<2<5<8<11<14<17<\\cdots\\]

The pattern is now noticeable. For each $k \\geq 1$, define the ordering $L_k$ on $\\mathbb{N}$ by placing all numbers $\\equiv 0 \\pmod{k}$ first, then $\\equiv 1 \\pmod{k}$, then $\\equiv 2 \\pmod{k}$, and so on
So $L_1$ is the standard ordering, $L_2$ is example (a), $L_3$ is example (b), and so on. This gives us infinitely many rankings on $\\mathbb{N}$. We claim no two of these are isomorphic.

The key invariant is the number of infinite blocks --- the number of equivalence classes under $\\sim$ (elements finitely far apart). Suppose $f: L_1 \\to L_2$ were an isomorphism. In $L_2$, the element $1$ (the start of the second block) has the property that infinitely many elements lie below it and infinitely many above it, with no element of the first block above it. There is no such element in $L_1$. The same logic continues. Since an isomorphism $f: L_j \\to L_k$ must send each $\\sim$-class of $L_j$ to a $\\sim$-class of $L_k$ (order-preserving bijections preserve the notion of \`\`finite distance between elements''), it would induce a bijection between the $\\sim$-classes of $L_j$ and those of $L_k$. But $L_j$ has $j$ classes and $L_k$ has $k$ classes, so if $j \\neq k$, no such bijection exists.

Hence $L_1, L_2, L_3, \\ldots$ are pairwise non-isomorphic, giving us infinitely many non-isomorphic rankings on $\\mathbb{N}$.

### Ranking of $\\mathbb{N}$ Isomorphic to $\\mathbb{Z}$

We can see using the structure intuition that a valid ordering would be\\[\\cdots<8<6<4<2<0<1<3<5<7<\\cdots\\]

### Ranking of $\\mathbb{N}$ Isomorphic to $\\mathbb{Q}$

This one feels almost impossible at first. $\\mathbb{Q}$ is dense — between any two rationals there is another — and $\\mathbb{N}$ with its usual ordering has obvious gaps. But remember: we are not using $\\mathbb{N}$'s usual ordering! We are asking whether we can rearrange the elements of $\\mathbb{N}$ to produce the same structural shape as $\\mathbb{Q}$.

This is in fact possible, by a beautiful back-and-forth argument (which is essentially the content of B7, Cantor's theorem). The key observation is that $\\mathbb{N}$ is countably infinite — just like $\\mathbb{Q}$ is countably infinite.

List $\\mathbb{Q} = \\{q_0, q_1, q_2, \\ldots\\}$. Define ordering on $\\mathbb{N}$ by $m <' n$ iff $q_m < q_n$. Then $(\\mathbb{N}, <') \\cong (\\mathbb{Q}, <)$ by construction.

### Embedding Any Countable Linear Order into $\\mathbb{Q}$

This result is the backbone of everything that follows. It says: no matter how you arrange a countable set, you can always faithfully represent that arrangement inside the rational numbers.

Let $L$ be a countable linear order. Then there exists an order-preserving injection $\\bar{\\cdot}: L \\to \\mathbb{Q}$, i.e., a function assigning to each $x \\in L$ a rational $\\bar{x}$ such that $x < y \\Rightarrow \\bar{x} < \\bar{y}$.

List the elements of $L$ as $x_0, x_1, x_2, \\ldots$ (since $L$ is countable). We build $\\bar{x}_n$ inductively.

Base case: Set $\\bar{x}_0 = 0$.

Inductive step: Suppose we have assigned rationals $\\bar{x}_0, \\ldots, \\bar{x}_{n-1}$ in an order-preserving way. To assign $\\bar{x}_n$:

- Let $A = \\{\\bar{x}_i : i < n, \\; x_i < x_n\\}$ and $B = \\{\\bar{x}_i : i < n, \\; x_n < x_i\\}$.
- All elements of $A$ are less than all elements of $B$ (by the inductive hypothesis preserving order).
- Since $\\mathbb{Q}$ is dense and has no endpoints, there exists a rational strictly between $\\sup A$ and $\\inf B$ (or just greater than all of $A$ if $B = \\emptyset$, or just less than all of $B$ if $A = \\emptyset$). Pick any such rational as $\\bar{x}_n$.

The result is an order-preserving injection.

The visual intuition here is compelling: think of $\\mathbb{Q}$ as an infinitely stretchy, infinitely divisible ruler. Whatever shape your countable linear order has, you can always \`\`fit'' it onto this ruler without distorting the relative order of points. The rationals are universal for countable linear orders.

### Cantor's Theorem — Any Two Countable Dense Orderless Linear Orders are Isomorphic

This is a masterpiece of mathematics. The statement: any two countable linear orders that have no smallest element, no largest element, and no gaps (i.e., are dense) are isomorphic to each other — and hence isomorphic to $\\mathbb{Q}$.

There are actually two ways to see this, and they feel quite different in spirit. The first is a direct construction. The second is the famous back-and-forth method. Both are worth understanding --- they illuminate different aspects of why the theorem is true.

### Proof via the embedding approach:

Recall that any countable linear order can be order-preservingly embedded into $\\mathbb{Q}$. That is, given any countable linear order $L$, we can find an injection $\\bar{\\cdot}: L \\to \\mathbb{Q}$ that respects the ordering.

Now suppose $L_1$ and $L_2$ are both countable, dense, and without endpoints. Apply B6 to $L_1$: we get an order-preserving embedding $\\phi: L_1 \\hookrightarrow \\mathbb{Q}$. The image $\\phi(L_1)$ is a countable sub-ordering of $\\mathbb{Q}$.

But is $\\phi(L_1)$ isomorphic to $L_2$? Not immediately --- $\\phi(L_1)$ might not be all of $\\mathbb{Q}$, and $L_2$ might not sit inside $\\mathbb{Q}$ in the same way. The embedding approach alone gets us inside $\\mathbb{Q}$ but does not immediately hand us the isomorphism between $L_1$ and $L_2$ directly.

Here is the fix. Apply B6 twice: embed $L_1$ into $\\mathbb{Q}$ via $\\phi$, and embed $L_2$ into $\\mathbb{Q}$ via $\\psi$. Both images are countable dense sub-orderings of $\\mathbb{Q}$ without endpoints. Now the key insight: a countable dense sub-ordering of $\\mathbb{Q}$ without endpoints is itself a countable dense linear order without endpoints --- so by the very theorem we are trying to prove, it is isomorphic to $\\mathbb{Q}$.

This feels circular! And honestly, it is --- the B6 approach alone cannot close the loop without already assuming the conclusion. It tells us that every such ordering embeds into $\\mathbb{Q}$, which is a strong and useful fact, but it does not by itself prove that any two such orderings are isomorphic to each other. For that, we need something more.

### Proof via Back-and-Forth:

This is where Cantor's real idea lives. Instead of embedding both orderings into a common host and comparing them there, we build the isomorphism directly between $L_1$ and $L_2$, piece by piece.

Imagine you and a friend are each handed an infinite jigsaw puzzle. You are told nothing about the picture --- only that both puzzles are countable, dense, and have no edges. Your job is to prove the two puzzles are identical in structure, without ever seeing the full picture at once. How do you do it? You match pieces one at a time. You pick a piece from your puzzle, find where it belongs in your friend's, then your friend picks a piece from theirs and you find where it belongs in yours. Back and forth, forever. The density condition is your guarantee that you never get stuck: whenever you need to place a new piece between two already-placed ones, density promises there is always room. The no-endpoint condition guarantees you can always extend outward in either direction. The proof uses the same logic. List $L_1 = \\{a_0, a_1, a_2, \\ldots\\}$ and $L_2 = \\{b_0, b_1, b_2, \\ldots\\}$. We build an isomorphism $f: L_1 \\to L_2$ in stages.

**Stage 0 (forth):** Set $f(a_0) = b_0$.

**Stage 1 (back):** Ensure $b_1$ is in the range of $f$. Look at where $b_1$ sits relative to $b_0$: if $b_1 < b_0$, use the fact that $L_1$ has no minimum to find an unused $a_i < a_0$ and set $f(a_i) = b_1$; if $b_1 > b_0$, find an unused $a_i > a_0$ and set $f(a_i) = b_1$.

**Stage 2 (forth):** Take the next unmatched element of $L_1$. It sits in some position relative to already-matched elements. The density of $L_2$ guarantees there is an available element of $L_2$ in exactly the correct relative position. Match them.

Alternating forth and back, every element of $L_1$ eventually gets an image, and every element of $L_2$ eventually gets hit. The result is an order-preserving bijection.
$\\square$

What makes back-and-forth strictly stronger than the embedding approach is that it builds a surjective map, not just an injective one. Embedding only gets us into $L_2$; back-and-forth gets us onto $L_2$ as well, by attending to both sides simultaneously. The alternation is everything.

The punchline is striking: up to renaming, there is essentially one countable dense linear order without endpoints. Call it what you like --- $\\mathbb{Q}$, $\\eta$, the rationals. All roads lead here. The rationals are not special because of what their elements are. They are special because of the shape they form.
    `
  },

  {
    slug: "delving-into-infinities",
    title: "Delving into Infinities [Linear Orderings Part 1]",
    date: "2026-04-18",
    category: "maths",
    status: "evergreen",
    description: "Part one: a tour of infinity through the lens of linear orderings, from the naturals to the rationals and beyond.",
    featured: true,
    draft: false,
    body: `
Recently, me being in my senior year of high school, I have being writing many mission statements. In questions similar to "Why math" or "Favorite instances in mathematics" I have written about Linear Orderings to the point that the admissions officers might assume that I just mugged up the name of one area of math to sound fancy. In actuality my mathematical journey has been long and varied; however the reason the particular math circle session stands out to me is because it was the first time I genuinely enjoyed being stuck in a problem. Currently, that's one of my favourite parts of mathematics. Yes- being stuck is frustrating however it feels more like the experience of running a marathon (or a swimathon in my case) where the struggle is immense but the feeling of satisfaction after the race makes you forget the pain and convinces you that the distance was fun. Moreover, getting stuck causes me to wiggle stretch and really push my brain to its limits, which I find just not possible if not challenged adequetely.

Lets get into the math itself. The most famous example used to teach infinities is the Hilbert's Hotel. The premise is really simple: there is a hotel with an infinite number of rooms numbered 1, 2, 3, 4, 5....

**Q. Suppose all the rooms are occupied. However, one more person desires to stay at the hotel. Normally you would turn him away but how can you use infinity to your advantage?**

Well, similar to how in grade school the largest number infinity was always usurped by infinity plus one, we shift all the guests one room to the right. 1 goes to 2, 2 goes to 3, etc. After this process, the room one is free to put the new guest into. (Note we can use the same process for any finite number k of guests that show up by shifting everyone from a to room a+k)

**Q. Now instead, an infinite number of guests show up?**

In this case, you can't use the same strategy as before- you'll end up having a guy walk up to infinity (which is not possible). Thus, we have to approach using a different strategy. The strategy we come up with is the following, shift every person to the room with double their current room number. The person in room 1 goes to room 2, the person in room 2 goes to room 4, 3 goes to 6, etc. This leaves us with all the odd numbered rooms to occupy the infinite new guests in. More specifically looking at the situation, we can see that the even numbers are an bijection of the natural numbers. That is to say we can simply map all the natural numbers without gaps onto the even numbers by doubling and vice verca. However, one infinity may also appear larger than the other. Take the natural numbers' set and remove the even numbers' set; we are still left with all the odd numbers. This would indicate that the natural numbers are a larger set than the even numbers contradicting the mapping argument. However, both are true as in subtracting the two gives a non null set yet both sets are of the same size. This is some of the intricacies of infinite sets.

**Q. Is it possible to map integers to natural number. In the infinite line of people what if it doesn't start neatly from 0 then 1, 2, 3, ... \\(\\infty\\) however expands infinitely in both the direction with no way to start?**

When trying to approach the positives and negatives separately you yield no results. Starting from the natural numbers then the negatives makes sense however -1 would be infinitth number (not allowed). Thus, we make use of the same anchor: 0. 0 then 1 then -1 then 2 then -2, etc. In essence all positive numbers n map to 2n-1 and negative numbers -n map to 2n.

**Q. We talked about mapping the integers numbers to the natural numbers. What about other sets, can we map rational numbers to the natural numbers. In other words, if an infinite number of busses (bus 0, bus 1, bus 2, bus, 3, bus 4, ...) show up with each an infinite number of people (bus 1 seat 1, bus 1 seat 2,...)**

Firstly, we note that the setup with an infinite number of infinite buses is equal to the rational number case. This is due to the fact that the bus numbers and the seat numbers are similar to the p and q of the r = p/q form of rational numbers. So how do we map rationals to natural numbers? Well, at first it may seem impossible not only are all the real numbers included in the rationals even if you label\\[a \\rightarrow 1 \\]\\[b \\rightarrow 2\\], there will be an unlisted number between them \\[c = \\frac{a+b}{2}\\]. However, to map the sets, we force properties of natural numbers. So how do we list all the passengers across all the infinite buses? Can we?

The answer is yes, and the trick is gorgeous. Instead of going bus by bus — which would trap us forever on bus $0$ — we go diagonally. Arrange all the pairs $(n, m)$ in a grid: rows are bus numbers, columns are seat numbers. Then trace a diagonal path through the grid:

\\[
(0,0) \\to (0,1) \\to (1,0) \\to (2,0) \\to (1,1) \\to (0,2) \\to (0,3) \\to \\cdots
\\]

![Diagonal enumeration of pairs of natural numbers](assets/img/writing/linear-orderings-1.png)

Every pair $(n, m)$ gets hit eventually. There is no hiding in this grid — trace far enough along the diagonal path and you'll reach any seat on any bus. This means we can assign every rational number a natural number: its position in this diagonal walk. And that is a bijection. The rationals are countable.

So here we are: the natural numbers, the integers, and the rationals are all the same size of infinity. The technical word for this size is $\\aleph_0$ (aleph-null). Any set that can be put in bijection with $\\mathbb{N}$ is called countably infinite. And one could be forgiven for thinking that all infinities must be countable. After all, we've been incredibly creative — diagonals, doublings, zigzags — and it's always worked. Surely every infinite set can be listed?

And then Cantor walked in and ruined everything. Beautifully.

###

### The Real Numbers: An Infinity Too Large to List

Can we list all real numbers between $0$ and $1$? Suppose — just suppose — that we could. Then we'd have some list:
\\[
r_0 = 0.d_{00}\\, d_{01}\\, d_{02}\\, d_{03} \\cdots
\\]
\\[
r_1 = 0.d_{10}\\, d_{11}\\, d_{12}\\, d_{13} \\cdots
\\]
\\[
r_2 = 0.d_{20}\\, d_{21}\\, d_{22}\\, d_{23} \\cdots
\\]
\\[
\\vdots
\\]
where $d_{ij}$ denotes the $j$-th decimal digit of $r_i$. Cantor's move is now almost theatrical in its simplicity. Construct a new number $x = 0.x_0 x_1 x_2 \\cdots$ by going down the diagonal and changing each digit: let $x_i$ be any digit different from $d_{ii}$ (say, $x_i = 5$ if $d_{ii} \\neq 5$, else $x_i = 3$). Now:

- $x$ differs from $r_0$ in the first decimal place.
- $x$ differs from $r_1$ in the second decimal place.
- $x$ differs from $r_n$ in the $(n+1)$-th decimal place.

So $x$ is not on the list. But $x$ is a real number between $0$ and $1$. Contradiction. No matter how cleverly you list the reals, there will always be a real number that escapes the list. The real numbers are uncountable.

There are strictly more real numbers than natural numbers. This is the first time we've encountered two infinities of genuinely different sizes.

This is where most courses stop. But for us, this is merely the warm-up. In the next post we move from asking how many elements a set has to asking something far more architectural: in what order do they sit?
    `
  },

  {
    slug: "anthony-bourdain-a-fan-letter",
    title: "Anthony Bourdain: A Fan Letter",
    date: "2026-04-04",
    category: "food",
    status: "evergreen",
    description: "A fan letter to Anthony Bourdain — on food, storytelling, and the people who take both seriously.",
    featured: false,
    draft: false,
    body: `
Literature
has always been a window into the human subconscious. While non-fiction
may be informative or even a tell into human motivation (for more
anecdotal writing), fiction holds a mirror to society and the human
condition. Characters in novels often go through the same innate
struggles as their authors. The worlds created often carry the same
dysfunctions as society. That being said, the idea that non-fiction is
oppositely cold and dry-cut is not accurate either. In fact, some of the
most raw glimpses into the human spirit come from real-life
storytelling that blurs the lines—like Anthony Bourdain's *Parts Unknown*.

It
masquerades as a food show but quickly reveals itself. Bourdain shows
you people and places as they are, unfiltered. Unlike most food shows,
he doesn't shy away from discomfort—talking about economic disparity and
government instability at a time when such things were mostly taboo.
And through food, he starts talking about history, identity, and how
something so ordinary ends up being what ties us together.

The
charm of the show is its reality. He doesn't bring in over-enthusiastic
TV personalities—he just brings himself. Dry, sarcastic, curious,
sometimes clearly uncomfortable. While most food shows want you to stare
at the food, Bourdain wants you to think about it. And about the people
making it.

And
the thing is—despite having what looks like one of the best jobs in the
world, Bourdain was clearly troubled. He didn't hide it. He didn't
decorate it. He let it be there. And instead of weakening the show, it
made it feel more human.

I
can honestly say that watching someone this endlessly curious, going
from place to place and asking questions that most people avoid, has
taught me more about being human than a thousand neatly packaged
philosophies ever could. More than that, it has greatly fostered my
interests in the culinary arts: one of my major interests other than
swimming, physics, mathematics, reading (a bit iffy nowadays), video
games, comics, manga, video game designs (all right I have a lot of
interests!).

The
interest in culinary arts is a very strange one. It all actually stems
from my inherent dissatisfaction with the cooking at home (mostly
because I'm a non-vegetarian stuck in a vegetarian household). The
eating non-vegetarian outside with my dad turned into dreaming about
it—as any self-respecting addict would. This metamorphosed into food
review shows that made me really hungry and finally shows like *Parts Unknown*.
Coupled with my insatiable appetite from swimming, I was classified
more a hog than a connoisseur. However, the fascination grew into a full
grown interest as I learned more about the creative aspects, the
precision, the chemistry of the field. Of course, imagining the flavours
of the food made is an added bonus!

Looking
at my other interests, one would be inclined to think the appeal to
food is something akin to chemistry you can eat. However, my connection
to food feels almost more natural and more sacred. It is the one thing
that everybody needs, not just for substance rather humans have an
almost artistic desire when it comes to food. Our bodies themselves
incline us to pursue this artform of analyzing flavour combinations,
chemistries of cooking, and textures. I myself try to keep true to the
Bourdain spirit, risking the bad meals to get to the really good meals.
Experimenting with food is almost always like that—you risk food
poisoning if you stick your neck out but it will always be an
experience. Most importantly, I like to carry out this philosophy into
life keeping an eternal curiosity.

As
I continue writing this, I realise I have meandered a lot and
romanticised food way too much. That is mostly because I am thinking
over my journey in this field as I write (I'm quite adept at talking
about the parallel in physics however that's because of writing college
essays).
    `
  },

  {
    slug: "magnetism-is-just-electricity-in-another-frame",
    title: "Magnetism is Just Electricity in Another Frame",
    date: "2026-04-03",
    category: "physics",
    status: "evergreen",
    description: "Deriving the magnetic force from special relativity, and why magnetism is just electricity seen from another frame.",
    featured: false,
    draft: false,
    body: `
Recently, I came across something that shook my whole understanding of electrodynamics. I had studied the different electric and magnetic fields their interactions and how one (quite mysteriously I might add) transforms to the other. A moving charge creates a magnetic field. A change in the magnetic field causes a current. Why do these different fields just change into each other based on the relative motion of their sources? The answer lies in special relativity. Rigorously of course, one could prove that the magnetic field is just the electric field in another reference frame using the relativistic transformation of the fields however, the setup that gave me intuition and helped build the idea is deriving the Biot Savart Law from special relativity.
\\[B = \\frac{\\mu_0I}{2\\pi r}
\\]
The setup

Take an infinitely long wire, we aim to find the force on a moving charged particle adjacent to such a wire. Of course, the force is\\[F = qv \\times B\\]
But consider this, what causes the particle to experience such a force in the first place. Special Relativity says that the force is due to the electric field of the wire. Looking at the setup we see that it is obvious that the wire doesn't have any electric field, it has equal number of protons and the electrons. The electrons move in the direction of the charge but they maintain the charge distribution. Thus, the system is neutral. How can it have an electric field. Well, I have said that according to Special relativity there is an electric field of the wire, so there must be some loopy relativity action going on; think about it, both the electrons and the adjacent charged particle are undergoing velocity (for simplicities sake we take both these velocities to be equal v), thus there must be some adjustments in the reference frame to be made. In the initial setup, we account for the charge density of the positive and negative particles in the wire.\\[\\lambda_+ +\\lambda_- = \\frac{dq_+}{dl} +\\frac{dq_-}{dl} = 0\\]This accounts for the neutral charge we assumed for the wire. Now we look at the system from the point of view of the adjacent moving particle of velocity v. Since the electrons in the wire are assumed to have the same velocity as the charged particle, they appear to be at rest whereas the positive metal cations appear to be moving backwards at speed v. Due to this relative motion, an effect of special relativity takes place called lenght contraction. Due to this, the positively charged cations appear to be closer together as the lenght shrinks.
\\[\\lambda_+' = \\frac{dq_+}{dl}\\gamma = \\lambda_+\\gamma\\]
Where gamma is the Lorentz factor\\[\\gamma = \\frac1{\\sqrt{1-v^2/c^2}}\\]
Additionally, we had measured \\(\\lambda_-\\) in the lab frame of reference where it was moving, whereas in the reference of the charged particle it is stationary. Thus we use a similar but opposite analysis\\[\\lambda_- =\\lambda_-'\\gamma\\]\\[\\Rightarrow \\lambda_-/\\gamma = \\lambda_-'\\]
Thus the new total charge density of the wire is\\[\\lambda_+'+ \\lambda_-' = \\lambda_+\\gamma + \\frac{\\lambda_-}{\\gamma} = \\lambda_+(\\gamma-1/\\gamma),\\;\\;\\;\\;\\;\\textit{Since \\(\\lambda_+ = -\\lambda_-\\)}\\]

Next, we find the electric field. The electric field of an infinitely long wire is taken as\\[E = \\frac{\\lambda}{2\\pi\\epsilon_0r}\\]
Thus the electric field of our wire in the moving reference frame is \\[E' = \\frac{\\lambda_+(\\gamma-1/\\gamma)}{2\\pi\\epsilon_0r}\\]
\\[\\Rightarrow F' = E'q = q\\frac{\\lambda_+(\\gamma-1/\\gamma)}{2\\pi\\epsilon_0r}\\]
This force must translate to the one we see in the lab frame of reference. \\[F = F'/\\gamma = qv \\times B\\]
\\[\\Rightarrow q\\frac{\\lambda_+(\\gamma-1/\\gamma)}{2\\pi\\epsilon_0r\\gamma} = qv \\times B\\]
Additionally, the velocity of the charged particle will be perpendicular to the circular magnetic field of the wire thus\\(qv \\times B = qvB\\)
\\[\\Rightarrow q\\frac{\\lambda_+(\\gamma-1/\\gamma)}{2\\pi\\epsilon_0r\\gamma} = qvB\\]
Additionally, we simplify the gamma terms:
\\[\\gamma- 1/\\gamma = \\frac{1}{\\sqrt{1-v^2/c^2}}-\\sqrt{1-v^2/c^2} = \\frac{v^2/c^2}{\\sqrt{1-v^2/c^2}} = (v^2/c^2)\\gamma\\]
\\[\\Rightarrow qvB = q\\frac{\\lambda_+(v^2/c^2)\\gamma}{2\\pi\\epsilon_0r\\gamma}\\]
Canceling the gammas, the qv's on both sides and taking \\(\\lambda_+v = I\\), we get
\\[B = \\frac{I/c^2}{2\\pi\\epsilon_0r}\\]
Additionally, \\[c^2 = \\frac{1}{\\mu_0 \\epsilon_0}\\]
\\[\\Rightarrow B = \\frac{\\mu_0 I}{2\\pi r}\\]
Hence the law is proved.

With this, we have shown an example of how the effect that we consider to be the magnetic field is merely the electric field under relativistic transformation. While proper transformation of the electrodynamic fields would give a clearer picture, this example gives intuition as to how the electric and magnetic fields are more closely related.
    `
  },

  {
    slug: "on-the-pauli-exclusion-principle",
    title: "On the Pauli Exclusion Principle",
    date: "2026-03-19",
    category: "physics",
    status: "evergreen",
    description: "Where the Pauli exclusion principle actually comes from: antisymmetric wavefunctions, not tiny magnets.",
    featured: true,
    draft: false,
    body: `
Quantum mechanics is the most nuanced and interesting field I’ve ever come across. From unfamiliar mathematical structures to intrinsic indeterminism and deeply paradoxical behavior, it is full of rules that sound simple—until you stare at them closely. Honestly, it’s a big part of why I love physics and also why I’ve started to genuinely like chemistry.

The Pauli exclusion principle is a perfect example. At first glance, the statement "no two electrons of the same spin can occupy the same orbital'' feels like just another neat rule to plug into chemical diagrams. It pops up everywhere in chemistry: orbitals, electron configurations, the periodic table. But once you pause and ask "why on earth should this be true?'', it stops looking like an arbitrary instruction and starts looking like a shadow of something deeper.

One tempting classical intuition is that the electron’s spin generates a tiny magnetic moment, and perhaps like‑spin electrons repel magnetically, so they avoid the same orbital. However, the magnetic interaction from intrinsic spin is orders of magnitude too weak to enforce anything as universal as the Pauli exclusion principle. The real origin isn’t electromagnetic at all. It comes from a more fundamental, more purely quantum property: the antisymmetry of the many‑electron wavefunction under exchange. In other words, the Pauli exclusion principle is not a force; it is a symmetry rule baked into the identity of particles that are fermions.

### Wavefunctions and identical particles

In quantum mechanics, the state of a system of electrons is described by a wavefunction $\\Psi(r_1, s_1; r_2, s_2; \\dots)$, where each argument corresponds to the spatial coordinates and spin of one electron. The key point is that electrons are identical: there is no physical label "electron 1'' vs "electron 2'' that an experiment can read off.

If you swap the labels,

\\[ \\Psi(\\dots, i, \\dots, j, \\dots) \\rightarrow \\Psi(\\dots, j, \\dots, i, \\dots)\\]

The physical situation doesn't change. That means the probability density $|\\Psi|^2$ must be the same after swapping. But the wavefunction itself is only has to stay the same up to a phase factor:

\\[ \\Psi(\\dots, i, \\dots, j, \\dots) = e^{i\\phi} \\, \\Psi(\\dots, j, \\dots, i, \\dots). \\]

Applying the swap twice should bring us back to the original labeling, which forces $e^{i 2\\phi} = 1$, so $\\phi = 0$ or $\\phi = \\pi$.

- If $\\phi = 0$, the wavefunction is symmetric under exchange: bosons.
- If $\\phi = \\pi$, the wavefunction is antisymmetric under exchange: fermions.

Electrons are fermions, so their total wavefunction must flip sign when you swap any two of them:

\\[ \\Psi(\\dots, i, j, \\dots) = -\\Psi(\\dots, j, i, \\dots). \\]

If you think of this as a kind of “identity check” for the labels, antisymmetry is the rule that says: if the labels are truly interchangeable, then swapping them must reverse the sign of the wavefunction.  Now suppose two electrons try to sit in the exact same state—same spatial orbital and same spin. Then the labels $i$ and $j$ become genuinely indistinguishable, and the wavefunction must satisfy

\\[ \\Psi(\\dots, i, j, \\dots) = -\\Psi(\\dots, j, i, \\dots),\\;\\;\\;i = j \\]

But if both electrons are really in the same state, the left‑hand side and the right‑hand side are literally the same function. So this equation becomes,

\\[ \\Psi = -\\Psi \\quad \\Rightarrow \\quad \\Psi = 0. \\]

The only consistent wavefunction is the zero function — which is not a physical state at all.  This is where the "no two electrons in the same state'' rule emerges: it’s not a force pushing them apart; it is the only consistent way to satisfy antisymmetry for identical fermions. The familiar "no two electrons of the same spin in the same orbital'' is just a low‑energy, approximate restatement of this more fundamental antisymmetry requirement once you split the wavefunction into spatial and spin parts and assume independent orbitals.

### What even is a state?

One of the questions that really bugged me is this: what exactly counts as a "state'' anyway? The usual phrase "no two electrons can be in the same state'' is hopelessly vague until you specify what basis you’re using.

Up until now, we’ve only had the restriction that only electrons of different spin can coexist in a state. Since there are only two spin directions, we consider that only two electrons can exist in a state. However, we still haven’t actually said what that state is. Is it a spatial orbital? An atom-sized region? The entire universe? Without a clear definition, the “state” label is just a placeholder.

This leads to questions:  

"Couldn’t a single state be the boundary of the atom, so that there are only two possible electrons in any atom?"

"Couldn’t a single state be the whole universe, so only two electrons in the universe?"

The catch is that the Pauli exclusion principle doesn’t apply to arbitrary, coarse‑grained blobs. It applies specifically to labels that are interchangeable within the same single‑particle basis. In typical atomic physics, the “state” is an eigenstate of the single‑particle Hamiltonian. If two electrons are in the exact same eigenvector of that Hamiltonian - same spatial orbital, same spin - the swapping mechanics that drive the Pauli exclusion system work. Even electrons in an adjacent orbital occupy an eigenvector orthogonal to the first, killing our lofty dreams of various two electron boundaries (Imagine the possibilities!)

At the end of the day, the Pauli exclusion principle is not some ad‑hoc rule plucked from chemistry; it is a direct consequence of the antisymmetric nature of fermionic wavefunctions. It explains why atoms don’t collapse, why the periodic table has the structure it does, and why "two electrons per orbital'' is a hard limit in the independent‑particle picture.

While this is one of my favorite instances of my physics rabbit holes, some questions remain unanswered for me which require more study into the multi-state Hamiltonians and the energy Hamiltonians.

1. Protons and neutrons are also fermions, yet they seem to clump together in the nucleus. While we know that states do not have to do with locality rather eigenvectors, what constitutes a single state in the nucleus? Do protons and neutrons even follow the Pauli exclusion principle?
2. Analyzing Ionization energy trends it is noticable that the electrons are more stable in the half filled and fully filled subshells than partially filled. While asking why, the reason apparently comes from the fact that electrons in the half filled subshell exchange energy in order to reach minimum potential. What are the eigenstates eigenvectors of the energy Hamiltonian that allow such exchanges? Do the exchanges behave similar to those of electrons in that they are non distinguishable particles thus can easily exchange while preserving the wavefunction?
    `
  },

  {
    slug: "riemann-zeta-function",
    title: "Riemann Zeta Function",
    date: "2025-05-22",
    category: "maths",
    status: "evergreen",
    description: "How 1 + 2 + 3 + … becomes −1/12, and what the Riemann zeta function is really doing.",
    featured: true,
    draft: false,
    body: `
Imagine a sum that keeps getting bigger: 1 + 2 + 3 + 4 + ... but somehow, its "value" is said to be

\\[1+2+3+4+5… = -\\frac{1}{12}\\]
This equation isn’t a joke. It isn’t a typo. And it definitely isn’t like one of those internet tricks that try to prove that 2 = 3.

But how?

Doesn’t calculus dictate that the sum should diverge?

How can an infinite sum of positive integers result in a negative fraction?

This equation is one of the paradoxical results of the famed Riemann Zeta function: \\[\\zeta(s) = \\sum_{n=1}^{\\infty} \\frac{1}{n^s}\\]

### First Encounters

My first encounter of the Riemann Zeta function was in a problem introduced to me in Math circle India:

What is the probability that two random numbers x & y are coprime i.e. gcd(x,y) = 1 for \\( x,y \\in \\mathbb N\\)

At first glance, it seems like an impossible question to compute. We’re picking 2 numbers at random — how do you even define a probability over an infinite set? There’s no upper limit, no finite set to compute over, yet there is a way to make sense of this idea. Not just a sense: an exact & surprising solution.

"To get there, let’s start by unpacking what it actually means for $x$ and $y$ to be co-prime." (two numbers are co-prime if they share no prime factors). Although we're dealing with an infinite set, we can think in terms of density. The probability of a number x being a multiple of p is \\(\\frac{1}{p}\\) as every \\(p^{th}\\) number is a multiple of p. In continuation, the probability that 2 numbers x & y being multiples of p is \\[\\frac{1}{p}*\\frac{1}{p} = \\frac{1}{p^2}\\] Therefore, the probability that both numbers are not multiples of p is \\[1-\\frac{1}{p^2}\\]

To ensure that no prime divides both x and y, we need to exclude all such shared divisibility across every prime. So we multiply over all primes:

Therefore, \\[P =\\prod_{p \\;prime} \\left(1 - \\frac{1}{p^2}\\right)\\] How does this relate to the zeta function?

Well, the zeta function is defined as \\[\\zeta(s) = \\sum_{n=1}^{\\infty} \\frac{1}{n^s}\\] at s = 2, this equates to \\[1+\\frac{1}{2^2}+\\frac{1}{3^2}+\\frac{1}{4^2}+…\\]
At first glance, this looks nothing like a product over primes. However, the key insight comes from something called the Fundamental Theorem of Arithmetic. The theorem states that any number can be written as a product of prime powers. That is to say: \\(n = p_1^{n_1} \\cdot p_2^{n_2} \\cdot p_3^{n_3} ... \\forall n \\in \\mathbb Z, p \\in prime\\).

Hence, \\[\\frac{1}{n^2} = \\frac{1}{p_1^{2n_1} \\cdot p_2^{2n_2} \\cdot p_3^{2n_3} ...}\\]
Therefore the sum \\[1+\\frac{1}{2^2}+\\frac{1}{3^2}+\\frac{1}{4^2}+…\\] can also be written as \\[(1+\\frac{1}{2^2}+\\frac{1}{2^4}+\\frac{1}{2^6}+...)(1+\\frac{1}{3^2}+\\frac{1}{3^4}+\\frac{1}{3^6}+...)(1+\\frac{1}{5^2}+\\frac{1}{5^4}+\\frac{1}{5^6}+...)...\\] And here’s the surprising bit: even though it looks like we’re only summing specific prime powers, this product actually captures every single \\(\\frac{1}{n^2}\\)\\). For example, for \\(\\frac1{2^2}\\) we multiply \\(\\frac1{2^2}\\) from the first multiplicand with 1 from every other multiplicand. For \\(\\frac{1}{6^2}\\) we multiply \\(\\frac 1{2^2}\\) from the first multiplicand by \\(\\frac1{3^2}\\) from the second multiplicand and 1 from every other. Similarly, we can form all \\(\\frac{1}{n^2}\\), thus equating the two expressions. Further we take: \\[(1+\\frac{1}{2^2}+\\frac{1}{2^4}+\\frac{1}{2^6}+...)(1+\\frac{1}{3^2}+\\frac{1}{3^4}+\\frac{1}{3^6}+...)(1+\\frac{1}{5^2}+\\frac{1}{5^4}+\\frac{1}{5^6}+...)...\\]\\[=\\prod_{p\\;prime}(1+\\frac{1}{p^2}+\\frac{1}{p^4}+\\frac{1}{p^6}+...)\\]Notice that each one of these multiplicands is a geometric series with the common ratio of \\(\\frac1{p^2}\\)\\[\\newline\\]
Since \\(\\frac1{p^2}<1\\):
\\[\\prod_{p\\;prime}(1+\\frac{1}{p^2}+\\frac{1}{p^4}+\\frac{1}{p^6}+...) = \\prod_{p\\;prime}\\frac{1}{1-\\frac{1}{p^2}}\\]
Therefore\\[\\frac{1}{\\zeta(2)} = \\prod_{p\\;prime}1-\\frac{1}{p^2}\\]
Therefore the probability of any two numbers being co-prime is\\[P =\\frac1{\\zeta(2)} = \\frac{6}{\\pi^2}\\] (The value of \\(\\zeta(2)\\) comes from Euler's famous solution of the Basel problem). To me, this solution to a seemingly unsolvable problem is interesting not only because it contains the Riemann Zeta function, it also has a surprising to \\(\\pi\\) and as a result, circles suggesting at a mystery conversation between the realms of geometry and number theory. 3Blue1Brown has an amazing video on this exact correlation linked here: [https://youtu.be/d-o3eB9sfls?si=1LsDzTDFRQUyiBjv](https://youtu.be/d-o3eB9sfls?si=1LsDzTDFRQUyiBjv)

### Back to \\(-\\frac1{12}\\)

This connection between the zeta function and prime numbers is only the beginning of a much deeper story. The Riemann zeta function can be extended to values of ss where the original series does not converge at all - like at s = -1, where the infinite sum 1+2+3+4+... obviously diverges. Yet, through a process called analytic continuation, the zeta function assigns this divergent sum a finite value: \\(-\\frac{1}{12}\\)

A fun yet wrong way (similar to the various tricks on the internet that try to prove that 1=2) to get the desired result of \\(-\\frac{1}{12}\\) is via manipulation of something known as the Grandi series. While this approach is wrong mathematically, it is still a fun exercise with infinite sets:

First, we take the set
\\[1-1+1-1+1-1+...\\]
Taking the sum \\(S_1\\) of the series we get three results!
\\[S_1 = (1-1)+(1-1)+(1-1)+... = 0\\]\\[S_1 = 1-(1-1)-(1-1)... = 1\\]
\\[S_1 = 1-1+1-1+1-1+1-1...\\]
\\[2S_1 = 1-1+(1)+1-(1)-1+(1)+1-(1)-1+... = 1\\]\\[\\Rightarrow S_1 = \\frac{1}2\\]The bracketed 1s are of the second \\(S_1\\)

In this, the first two equations are known as partial sums of the oscillating function.
Notice that the third sum is the average of the two partial sums also known as a Cesàro sum.

Next, we look at the series:
\\[1-2+3-4+5-6+...\\]
We calculate \\(S_2\\)
\\[S_2 = 1-2+3-4+5-6+...\\]\\[2S_2 = 1-2+1+3-2-4+3+5-4-6+5+...\\]\\[\\Rightarrow2S_2 = 1-1+1-1+1-1+... = S_1 = 1/2\\]\\[\\Rightarrow S_2 = 1/4\\]
Finally we take the series:\\[S_3 = 1+2+3+4+5+6+...\\]\\[S_3+S_2 = 1+1+2-2+3+3+4-4+5+5+6-6+...\\]
\\[\\Rightarrow S_3+S_2 = 2+6+10+14+18+...=2(1+3+5+7+9+...)\\]
\\[\\Rightarrow S_3+S_2 = 2(S_3-2S_3)\\]
\\[\\Rightarrow S_3 = -S_2/3 = -\\frac{1}{4*3} = -\\frac{1}{12}\\]

Thus we get our miraculous result! However as I mentioned earlier, this solution is not correct. The reason for this is that we are treating divergent functions as convergent in the sense of adding and subtracting them. Moreover, as those who have studied calculus would agree, addition and subtraction of said infinities lie in the indeterminate form of limits as \\(\\infty-\\infty\\) can be anything: 0, a constant or even \\(\\infty\\). While the Grandi-style manipulations are mathematically shaky, it is not true that \\(-\\frac{1}{12}\\)is wrong too. It is actually a value that emerges not from set manipulations rather from a rigorous mathematical process called analytic continuation of the Riemann Zeta function.

### More on the Riemann Zeta function:

So, what does \\(-\\frac{1}{12}\\)actually mean then? While the Grandi-style manipulations are entertaining, they aren’t mathematically rigorous. The series 1+2+3+4+… diverges — it grows without bound — and no traditional method of summing it gives a finite result. However, this value of \\(-\\frac{1}{12}\\) does appear in a rigorous way via complex analysis.

The Riemann Zeta function is defined to be \\[\\sum_{n=1}^{\\infty}\\frac{1}{n^s}\\] The Riemann Zeta function is defined to be \\[\\sum_{n=1}^{\\infty}\\frac{1}{n^s}\\] Which only converges when the real part of s, say s = a+bi, is greater than 1. For values of \\(a \\leq 1\\), the series diverges. So how do we get to values like \\(\\zeta(-1)\\)? Analytic continuation.

In short, analytic continuation is the process of extending the graph for the complex function in such a way that it is continuous and differentiable for all values. But in order to complete graphs, we have to have the graph in the first place.

How do we make graphs for complex functions in a meaningful way? Complex functions take complex inputs and give complex outputs — which means both the input and the output each have two dimensions (real and imaginary parts). That’s a total of 4 dimensions! To visualize the complex function \\(\\zeta(s)\\), we use a technique called grid transformation. This involves starting with a regular lattice (grid) on the complex plane — a set of horizontal and vertical lines marking points with fixed real and imaginary parts. We then apply the zeta function to each point on this grid, effectively mapping every input s to its corresponding output \\(\\zeta(s)\\). As a result, the entire grid gets warped and transformed, revealing how the function stretches, twists, or compresses regions of the complex plane. The final image, like the one shown below, provides a powerful visual insight into the behavior of ζ(s)ζ(s) across the complex plane.

![The Riemann zeta function on the complex plane](assets/img/writing/riemann-zeta-1.png "Credit: 3Blue1Brown")

This graph however stops abruptly at the vertical line Re(s) = 1. This is where the concepts of analytical continuation comes in. Essentially, we extend the graph of \\(\\zeta(s)\\) in such a way that it is both differentiable and continuous. However, this seems to lead to an infinite number of possibilities! To ensure that it is continuous, we just have to continue the graph without lifting our pencils and to ensure that it is differentiable, we just have to make sure that we draw no sharp corners right? Not quite. While that intuition works for real functions, we’re in the realm of complex analysis now — and the rules are a bit different. In the complex world, differentiability means much more than just being smooth. It implies something called holomorphicity, which requires the function to preserve angles and local shapes — a far stricter condition. So when we analytically continue \\(\\zeta(s)\\), we’re not just sketching a visually smooth curve; we’re extending it in a way that maintains the angle-preserving structure across the complex plane. These constraints finally allow us to settle on a single shape for the graph of \\(\\zeta(s)\\) as seen below.

![Analytic continuation of the Riemann zeta function](assets/img/writing/riemann-zeta-2.png "Credit: 3Blue1Brown")

Moreover, this graph finally allows us to make sense of non trivial equations such as \\[1+2+3+4+... = -\\frac{1}{12}\\] by plugging in values such as \\(\\zeta (-1)\\) in our now complete graph.

Hence, we finish our journey to prove the nonsensical: An infinite sum of positive numbers can be a negative fraction. This is just a first glance into a strange and beautiful world of complex analysis, but it already feels like a playground of ideas. I would like to end by apologizing in advance on the rushed explanations at the end, they are the result of my relative inexperience to the field. In a way, I have been learning with you readers while writing this post

Credits:

Graphs by 3Blue1Brown
    `
  },

  {
    slug: "the-speed-limit-of-the-universe",
    title: "The Speed Limit of the Universe",
    date: "2023-07-04",
    category: "physics",
    status: "evergreen",
    description: "Why the speed of light is the universe's speed limit, and what happens as you approach it.",
    featured: false,
    draft: false,
    body: `
![The Flash getting a speeding ticket](assets/img/writing/speed-limit-1.png)

Most of us who are fans of the superhero Flash
would have wondered; how fast can he go? There is a very strict speed limit
that he has to adhere to and that is not just because he has signed some
contract with the production company. This speed limit comes from the inherent nature of reality itself and is none other than the speed of light. One may then be led to ask how did this speed of 3*10^8 m/s become
the speed of our wide wild world anyway? Many of the physics geeks may already
have guessed it: The Special theory of relativity. Before we plunge into this
weird and complex part of special relativity, we must dip our toes into the old
relativity.

What is relativity? Relativity is sixes and
nines, allow me to explain. Suppose you write the number 6 on a piece of paper.
For you, it is the number six but to a person standing on the opposite side of
the paper, it will be nine. We also experience relativity every day with motion. When
you are on a train, you and the other people on the train
seem to not move whereas the world and the people outside seem to be moving
backwards. Whereas if you are a person on the platform, you would see all the
people in the train moving past you. Let’s complicate this just a little,
let’s say that a person on the train gets up and starts moving in the direction
of the train. To the person sitting in the train, it would look like he is just
walking at a normal walking speed whereas to the person on the ground, the
person walking in the train is travelling at his speed plus the speed of the
train. So you see? It’s all relative. Newton’s and Galileo’s most prominent
contribution to relativity was that nothing is absolute. We are used to
measuring speeds and direction with respect to the Earth but isn’t the Earth
also moving with respect to the sun and isn’t the sun also moving? Wouldn’t it
be a weird reply to the question “Do you know what speed you were travelling
at?"

"Relative to Earth, the Sun, or the Milky
Way?" This all seems to make sense, doesn’t it? But along came James Clerk
Maxwell announcing that the speed of light is constant for all observers. This
very proclamation shattered the physics community and thankfully Einstein came
along to fix it with all his time travel, length contraction, etc.

So how in The Special Theory of Relativity
does light become the speed limit of the universe? It all has to do with mass.
E=mc2? No, it has to do with the equation:

![Relativistic mass equation](assets/img/writing/speed-limit-2.png)

The m' (m prime) in the equation is mass you observe if the object is **moving past you** and the m is the mass that you measure the object has when it is **stationary relative to you**. What this equation means to say is
that the faster you go, the more your mass increases. Well, so you get heavier?
Not exactly.

What most people get wrong is that this equation is talking about
inertial mass. Inertial mass is also a phenomenon observed in our everyday
lives. What would be easier to get rolling a real boulder or a hollow plastic
one of the same size? The plastic one. And which one is easier to stop? Again,
the plastic one is. We can infer from this that the more the mass increases, the
harder it is to change its state of motion. That is inertial mass. You can make sense of the concept that inertial mass increases when an object is traveling faster if you carefully observe the equation. The relativistic mass as in the mass you observe an object to have if you move past it is on the left hand side and the stationary one on the right. The equation shows that the relativistic mass is equal to the stationary mass divided by something. Since it is such, shouldn't the relativistic mass be smaller than normal mass as division makes a number smaller. Not if you divide by a number smaller than one and greater than or equal to zero. Luckily for us the denominator is within that range as velocity can never be greater than the speed of light.

Again, why is that? I haven't explained it have I? If you plug
in the velocity to be the speed of light, one’s inertial mass becomes infinite. That is
to say that it would require infinite force and energy to slow down or speed up. And that
is why Flash has to adhere to this speed limit and also the reason why you
can’t slow down light no matter how much force you put against it.
    `
  },

  {
    slug: "how-to-find-and-understand-dinosaur-fossils",
    title: "How to Find and Understand Dinosaur Fossils",
    date: "2022-03-31",
    category: "biology",
    status: "evergreen",
    description: "A beginner's guide to finding, reading and understanding dinosaur fossils.",
    featured: false,
    draft: false,
    body: `
Paleontology doesn’t automatically mean dinosaurs but today, I am going to talk about dinosaurs. Paleontology is the study of any ancient animal through its fossils. Fossils can be any trace left behind by the extinct species that give us information on them. The word fossil means “dug up”. Bones? They are fossils. Imprints? They are fossils. Your cycle in a hundred years? Not exactly. You see, a fossil is a trace of a once-living organism and even though a cycle shows the evidence of a rider, it is not directly a remain of a living being. Now that what paleontology is has been clarified let's move into it. Today, most of the references of paleontology will go to a subsection that studies the dinosaur era namely, the Mesozoic or middle era.

How do paleontologists find and understand dinosaur fossils? Let’s start with finding the dinosaur fossil. The answer is, nobody knows. That’s disappointing, right? What I mean to say is that paleontologists cannot be sure about where to find fossils indefinitely but can make educated guesses. If we had a giant dinosaur scanning radar, we would have all the fossils there are in the world.

### How to make an educated guess on where to start digging up for dinosaurs:

**Don’t go digging up your backyard, you’ll make a mess**

**Find the geological area of the right age:**

You can get this information on a geological map. You can look for anything as old as 245 million years and also look for relatively new rocks of 66 million years

**Find a desert:**

You need to find a desert because vegetation may cover up the dig and also destroy the fossil. An arid region also allows weathering to expose the fossil on the surface otherwise it would not be found

**The rock should be sedimentary:**

This is because the other rock formation processes destroy fossils

**Get as far away from other paleontologists as possible:**

Once you have followed the earlier rules, there is a high chance of finding dinosaur bones. Sure, you may find a T-Rex skull but that is only satisfaction for yourself. If you go to uncharted territories (paleontology wise) you have a higher chance of discovering a new species.

**Give it a good name:**

Unlike past names like the IRRITATOR or the DRINKER

There you go, a step to step guide to being an amateur paleontologist.

Now that you have a fossil, what do you do with it aside from keeping it as a showpiece?… You learn more about it.

First of all, you can find out about their habitat. You found the bones in the desert so they must be from there right? You’ve all seen Jurassic park so you know that dinosaurs live in a wide variety of habitats. Looking just at the fossils, you can’t figure out whether they lived in a desert, forest, swamp, etc. Here, you use a science called sedimentology. Sedimentology is the study of sed

By looking at the sediment rock that the fossil is found in, we can conclude what they used to be. See, sedimentary rocks are made when sediments or particles are squeezed together with immense force to form a rock. This can occur when sediments such as sand or gravel form a layer of say, a beach but over time they compress due to the weight of the new layers to form a sedimentary rock. Using the knowledge of sediments we can figure out what an area used to be like. For example, if a dinosaur fossil is found in sandstone, the sediment is sand and that indicates that the habitat was a beach, an ocean bed or a river channel. Shale or mudstone indicates mud and silt as sediments indicating a lake bottom environment. Coal is formed by the remains of dead animals and plants so a coal deposit indicates that it used to be a swamp or forest. Finding fossils in forests is very unlikely but we’ll see to that later. Finally, Limestone is made up of sediments of Calcium Carbonate which is found in the shells of crustaceans so it indicates a shallow marine environment.

Now getting back to the topic of why the fossils of dinosaurs who lived in forests cannot be found. For a dead animal to fossilise, a lot of things need to go just right: the right environment, timing, and conditions and the fossils also need to survive millions of years and then resurface before natural processes dissolve the fossil. For example, lush jungles prevent fossilization as the chances that an animal will be buried here are minimal. Countless scavengers of all sizes break down freshly deceased animals extremely quickly and the soil is often so acidic that bones are dissolved. And so fossils of dinosaurs from jungles are practically nonexistent. This is sad as even today, HALF of all animals live in lush jungles that cover only 2% of the Earth’s surface. Back then, jungles covered a huge present of landmasses. This means that most of the dinosaurs that lived are lost to us forever.

Thinking of dinosaurs, we think big but what about the little ones. Dinosaurs had babies of course… they laid eggs. Now earlier, in the 1900s, all the museums wanted bigger and better dinosaurs. It took paleontologists a while- actually decades to ask the question- Where are the little ones? Throughout the 20th century, the common belief was that there were big dinosaurs and smaller versions of the dinosaur. But they could not find any little Dracorex Hogwartsia, or any little Torosauruses, they didn’t find many juveniles at all! Well, the problem had something to do with a scientist wanting to name something. You see, a scientist has a deep-seated want to name something so even when they saw a slightly different dinosaur, they named it differently. This caused a lot many species. The problem was that many dinosaurs had something called allometric cranial ontogeny. This means that different parts of their head grow at different speeds. So a juvenile triceratops will not have the same cranial proportions as a fully grown one. This is a problem because scientists that wanted to name stuff classified the same species as different because they ignored allometric cranial ontogeny. The only way to figure out if the dinosaur is juvenile or fully grown is to cut its bone. If you cut into a juvenile dinosaur’s bone, it is spongey but an adult's bone is compact and solid. But you can’t go to a museum and ask them if you can cut their dinosaur’s skull. It turns out that many dinosaurs that were classified as cousin species are the same animal. By looking at similar “cousins” and cutting their skulls we found out that Dracorex, Stygimoloch, and Pachesephalosaurus, despite having different features are the same animal. A palaeontologist named Jack Horner cut into a now classified as juvenile triceratops and found it to be spongey and then he cut into a sub-adult Triceratops and it was spongey but when he cut into an adult triceratops’s skull, it was still spongey! So he took a closely related dinosaur called Torosaurus and found it to be compact and adult. Now, many would say that Torosaurus has holes in its frill so it can’t be the same creature but when they saw the skulls, they saw micro holes in the triceratops’s skull and those were seeming to have to grow larger as evident from its cell pattern. So, even though we seem to focus on bigger dinosaurs, growth is something that we have to keep in mind.
    `
  },

  {
    slug: "has-doomsday-arrived",
    title: "Has Doomsday Arrived?",
    date: "2022-03-31",
    category: "environment",
    status: "evergreen",
    description: "A survey of the climate headlines that should have woken us up — and an explanation of the greenhouse effect behind them.",
    featured: false,
    draft: false,
    body: `
**2021 was Earth’s fifth-hottest year, scientists say**
*January 11, 2022- Indian Express*

**UN agency confirms record 38 degrees Celsius heat for the Arctic**
*December 14, 2021- Indian Express*

**Arctic thaw threatens human habitation**
*January 12, 2022- BBC News*

**Climate change: For 25th year in a row, Greenland ice sheet shrinks**
*Friday, January 07, 2022- UN News*

**Polar bear population decline a wake up call for climate change action**
*WWF (World Wide Fund for Nature)*

The
above headlines give you a grim picture of the sad situation that our
planet is in. These are just a few of many such that. Have been
emboldened across newspapers and yet, humanity has still not woken up.

Global
warming IS a WORLD ISSUE. No! It’s not just the unlucky eskimo whose
house keeps melting it is an issue for you and me too. We all like to
live with technology, electricity, go on rides in cars, and much more so
why shouldn’t we too shoulder the blame of global warming? Every single
person on the planet is responsible for global warming. Every single
person also suffers the consequence. Melting of ice-caps cause sea
levels to rise. Hotter and drier climates cause forest fires. Water
bodies that we are dependent on evaporate away do the the change in
climate.

### **How**

Global
warming is happening because of pollution, but how? You’ve been told
that AC’s and Refrigerators cause cause global warming but they are cool
aren’t they so how do they heat the planet? The greenhouse effect is
named after greenhouses for a reason. Greenhouses are designed such that
light and heat can enter the green house but it gets trapped by the
glass panels heating up the greenhouse. The same thing is happening with
the Earth. Gasses like carbon dioxide, methane, nitrous oxide,
chlorofluorocarbons CFC’s, etc. (the greenhouse gasses) form a layer in
the atmosphere that does the same thing as the glass panels in the
greenhouse. It traps the heat from the sun. Over the years, due to
pollution, more and more greenhouse gasses have been produced trapping
more heat than ever in the Earth’s atmosphere.

The animal husbandry sector is another major source of carbon emissions
that is often neglected. In the year 2020, cattle released the methane
equivalent of 3.1 gigatonnes of carbon dioxide into the atmosphere (plus
a tiny amount from farting). Though even humans often fart and burp
methane, it doesn’t cause as much of an effect because we do it on a
much smaller scale. This is mainly because of the cow’s diet along with
its gastronomic system. This can easily be solved much like human farts,
by changing the cow’s diet to eliminate methane and carbon emissions.

In
the year 2022, the globe relies on energy to power houses,
telecommunication, laptops, computers, mobile phones, cities,
agriculture, and practically every aspect of our life. Coal power plants
provide a majority of that power. Even though it doesn’t look like it,
our energy production is wildly inefficient. We practically burn fossil
fuels or even exploit a large energy resource such as nuclear fission to
boil water which makes steam that then rotates a rotor(fan). This is
how humans create electricity and it is a huge toll on the environment.
Not only does it create a lot of pollution, but because our energy
production is so inefficient we seem to have to cause a lot of
pollution. There are certain renewable energy options that can help us
reduce our reliance on fossil fuels. Due to them being weather
sensitive, we'd need more batteries than the world now has in order to
to power everything on days when the weather isn't conducive for
generating electricity.

### THE GLORY DAYS ARE OVER

A
recent theory is that the covid 19 pandemic was caused due to global
warming. There is a layer of ice in the Earth called the permafrost
which has preserved many ancient pathogens and organisms. Due to global
warming the permafrost is melting. The theory states that covid 19 is an
ancient pathogen that was released due to the thawing of the ice. We do
not know how many such pathogens can be released due to further global
warming. Global warming causes yet another serious problem, the thawing
of the arctic ice. Aww… poor polar bears and sea-lions…. No! Wait! The
melting of the arctic ice also affects you! The arctic ice plays a major
role in the Earth’s climate. Due to its white colour, the arctic ice
cover reflects back most of the sun’s light whereas black absorbs 99% of
heat from the sun. Since 1980, the summer Arctic cover has decreased
about 40% exposing dark shades of oceans and rocks. This is heating up
the planet exponentially. The ice has melted, now what? The water levels
rise of course. This is a serious problem for coastal cities and
villages. R.I.P. Netherlands, we shall surely miss you. Apart from
countries that are already under sea level, major cities like London and
Mumbai stand the risk of being flooded.
Not only humans but even
animals suffer because of global warming. Forest fires caused by hotter
and dryer climates cost the homes of hundreds of animals. Many arctic
animals that depend on the sea ice as a home are unable to survive do to
its thawing. The Earth’s climate has exponentially changed earlier too
but because it was the work of nature, the climate changed in a gradual
manner. This allowed flora and fauna to adapt to the change in
temperature. Because the warming of the Earth in recent years is very
fast, animals and plants that cannot adopt go extinct.

One of
the first examples of animals going extinct due to global warming is
golden toads. This species of toad went extinct in 1989.

The
Adelie penguins are a penguin species that inhabit the whole coast of
the Antarctic continent—it is in fact their only habitat. They feed on
krill that take refuge under the ice sheets and feed off algae. The
krill population is dwindling as the ice sheets of the Antarctic is
melting off, and so the penguins have to travel out of their natural
habitats in search of food.
This causes them to lose energy—if they
even succeed without dying—that could have been used in breeding and
caring for their offspring. As a result they lose some of their young.
Over all, the population of Adelie penguins is at the brink of
extinction.

“The largest coral reef in the world, Australia’s
Great Barrier Reef has not been spared the effects of global warming.
Widespread coral bleaching caused by increases in sea surface
temperature have become more frequent in the past few years. If global
warming continues unchecked, it is estimated that the sea surface
temperature could rise by 2 to 6*C (3.5 to 10*F). There is also an
alarming prediction that this World Heritage designated site could be
decimated by 2050 losing more than 90% of its living coral.”

Global Warming Witness
National Geographic Magazine (June 2007)THERE IS HOPE

### THERE IS HOPE

All
of the past pages have painted a grim picture of the state of the
Earth due to Anthropogenic activities. In the drive to further our
civilisation, we have been exploiting mother Earth and her resources.
The fuel (literally) of our civilisation is electricity. Most of it is
produced by burning fossil fuels of natural oils. This polluted the
Earth and because of the greenhouse effect, heated it up. Now, we can’t
fly up in the air with a giant vaccum cleaner and suck up all the
greenhouse gasses but we can reduce the emissions that we make.

There
is ongoing research into nuclear fusion energy with the goal of making
it so energy efficient that a single glass of seawater can provide as
much energy as a barrel of oil with minimal environmental impact. Though
this appears to be the answer to all of our problems, the catch is that
it is unproven, and research to develop working reactors is a $10
billion gamble that the world is not yet ready to accept because we
don't even have a working prototype.

Many
experts feel that rather than trying to develop a whole new renewable
energy source, we can improve the efficiency of the ones we already
have. The most used of these is hydroelectric power because it can
produce the most electricity. This renewable energy just doesn’t seem
that renewable anymore due to the fact that we used it to its saturation
point. A famous example of this is the Colorado River near Las Vegas.
Because it is such a huge river, humans exploited it for their own good.
They built 15 dams on the main river and hundreds of more on its
tributaries. What was once a great river, now has dried up because of
over use. This will be the case in many rivers around the world if we
continue hydroelectric power on a large scale. Although, if we use micro
hydroelectric power, small rotors instead of dams, the process could be
more sustainable. One of the major problems in relying on solar and
wind energy sources is that the generation of electricity is dependent
on weather. For solar panels, cloudy days would cause a problem. For
windmills, the shortcoming is days with no wind. A planned combination
of renewable power (Windmill with Solar Panel Blades) generation with
wind and solar farms generating power during their favourable times and
temporary shortfall managed through planned storage with additional
power generated through the use of biomass at point of consumption can
help us drastically cut our reliance on non-renewable fossil fuels for
our power needs.

As
for the effects of climate change that we have brought unto ourselves,
with the most prominent one being sea levels rising, we have to deal
with it. As earlier stated, many countries may flood due to the rise in
sea levels. One country that has dealt with it before is Netherlands.
Due to most of it being under the sea level and also lying along the
delta of three major European rivers, Netherland received oceanic floods
that killed thousands. Due to this, Netherlands started developing
flood prevention system called delta works. It is the most sophisticated
flood prevention project on the planet. They first used dams to block
the estuaries near the mouth of the delta where flood water could surge
inland. These estuaries were transformed into lakes that served as
nature reserves. Next for the passage which used for all shipping into
the countries docks, they had to make a mobile flood prevention to
preserve the passage. They created the Maeslantkering, the largest
moving structure on Earth to act as a barricade that could be closed
during floods and opened at other times.

After
the success of its own flood prevention system, Netherlands is working
on helping other countries that are under the threat of flood to cope
with the 30 million cubic km more water in the sea that would happen if
global warming continues.
    `
  },

  {
    slug: "industrial-revolution-and-the-information-age",
    title: "Industrial Revolution & the Information Age",
    date: "2022-03-31",
    category: "history",
    status: "evergreen",
    description: "How the Industrial Revolution created the conditions for the Information Age, and what that says about where we are now.",
    featured: false,
    draft: false,
    body: `
Art is made when there is free time. In ancient civilisation, good yield allowed civilisations to grow culturally, create masterpieces, think, engineer, create republics, start revolutions, and innovate. Most of our history is spent as hunter-gatherers. We controlled fire and had tools made from wood, stone and bone, told stories, mourned our dead and created art. We traded with other tribes. Some hunted big game and were very mobile, others relied more on plants they collected and others mostly stayed in one area with an abundance of seafood. This was the common state of humanity for most of our history. Then, roughly 10,000 years ago, we discovered farming. From a nomadic lifestyle, we settled down, reared animals and when there was time, instead of going for a hunt, we innovated. As a more stable lifestyle was developed, humans began to flourish. More mouths to feed forced farmers to come up with innovative tools that made human work easier and productivity rose.

And then in 1760, started the industrial revolution. We had earlier branched out and specialised in our free time but now all the fields grew. We created the steam engine, established factories, produced secondary items in mass, and there was a steep specialisation in industries. It was an explosion of innovation. While it eradicated old jobs, it made even more new ones. For example, there was the automobile industry. When it was introduced, it abolished the jobs of horse carriages but along with the production of cars, they made various industries like drive-ins, petrol, traffic control, etc. So while it destroyed a few jobs, it gave rise to new industries. Many moved from villages to cities for a better standard of living resulting in congestion and overcrowding. Because of the large number of people in the city, many were left jobless and had to do menial jobs to earn money. A popular example of these jobs was sewer scouring where people worked in dangerous conditions to get trinkets from the sewers. The industrial age was also a huge positive as it replaced most of the primary industries for the secondary or production industry.

When we were farmers, we used to work in the primary sector. With the industrial revolution, we shifted to production jobs and as more and more things became automated, we shifted into service jobs. While the earlier examples of innovation show that it destroys some jobs but creates many better ones, nowadays, the internet allows us a lot of production by less number of people.
For example, At its peak in 2004, Blockbuster had 84,000 employees and made $6 billion US dollars in revenue. In 2016, Netflix had 4,500 employees and made 9 billion dollars in revenue.
This is very bad on its own as not as many jobs are being created as they are being destroyed, but we also have a growing population that needs more jobs. So aside from replacing the old jobs, we also need to create new ones for the growing demand.

All this sounds grave, but it gets even worse. In recent years, machines have been taking on more and more jobs. Machines are only good enough to do repetitive factory work but even if we take a hard long look at any job, it is just repetitive sequences of actions. Machines do this via machine learning where they learn by analysing data. This is a problem as humans are nowadays recording everything from Medical Records, Behaviour, Weather, Heart Rates, Communication Systems, Travel data, and what we do at work. Essentially, we have created a huge library for machines to learn how to do the stuff we do better than us.

These may be the biggest job killers of all. They can be instantly replicated, are free to upgrade, and are fast.

This is already happening. Some companies are creating machine learning software that eliminates management positions. They decide the tasks that can be done by computers and which need actual humans. They then assemble a team of freelancers and monitor the work till the project is done. This seems harmless at first glance but the machines examine how the freelancers do their jobs and then learn to do them themselves. This is very cheap for the companies and tends to be the more attractive option.

This can result in a dystopian future where there is a tiny minority of the super-rich who oppress the others or, it doesn’t have to be so grim. If we harness it in the right way, the information age can be used to eradicate inequality
    `
  },

  {
    slug: "judaism-the-oldest-and-unluckiest-monotheistic-religion",
    title: "Judaism: The Oldest and Unluckiest Monotheistic Religion",
    date: "2022-03-31",
    category: "history",
    status: "evergreen",
    description: "A short history of Judaism, the world's oldest monotheistic religion, and the persecution that runs through it.",
    featured: false,
    draft: false,
    body: `
Judaism is the world’s oldest monotheistic religion but is also the ethnic group most subject to persecution and prejudice. It originates from the Fertile Crescent of Egypt. Judaism first started as tribes that followed a monotheistic order but as the Egyptian monarch slowly infiltrated the fertile and barren crescents of the Nile, Jews were treated as second class people and were enslaved. The most prominent story in Judaism is that of Moses. He was a child in one of the Jewish tribes that were being persecuted by the Egyptians when his sister sent him away in a basket as a baby. He was later found by one of the princesses and raised as royalty. Growing up, he found the persecution of Jews unfair. An inciting incident in his life was when he saw an Egyptian beating up a Jewish slave and unable to control his anger, Moses killed him. He then led the Jews to freedom from the Egyptians. He lead them through the desert to the promised land of Cain (land of nod).

The origins of anti-semitism lie in the Time when Romans captured the land of the Jews. They followed a pagan polytheistic religion, that they tried to impose on the Israelites. The Jews, following a monotheistic religion that they thought superior, refused. This started the persecution of the Jews in Israel and Palestine by the Romans. For many years, the Jewish ethnicity was suppressed by the Romans. In these dark times, the Jews only had one hope, a messiah or a messenger of God. This messiah is later to be known as the son of God: Jesus Christ by the Christians.

Though the origins of Christianity lie in Judaism, for centuries, Christians and Jews were rivals. In truth, Jesus Christ was a Jew who preached not of another religion but a deeper understanding of the Jewish religion. Seeing this protestant belief of Judaism, the religious leaders of the time called it blasphemy and reported it to Pontius Pilate. Pontius Pilate was the Roman general posted to administer the areas of Palestine and Israel. So long as he kept the countries peaceful and submitted the tax to the roman empire, he was an effective dictator. It is a lesser-known fact that he saw Jesus Christ as innocent but prosecuted him for the sake of peace and stability. The Christians later blamed the Jews for the death of their leader causing a rift between the two religions. The Jews were later exiled by the Romans and dispersed across the vast roman empire

The drift between Christians and Jews was later exhibited in the crusades. The crusades were a series of religious wars between Jews, Muslims, and Christians who were fighting for the holy land. The Jews who had a weak army were massacred by the crusaders. This forced many to migrate to distant corners of Europe. The crusades signify the closeness of the three religions that many seem to want to ignore. In the many corners of Europe, Jews were denied citizenship rights and were considered alien. The persecution of Jews in western Europe continued until the late 18th century.

During the age of enlightenment, many scholars blamed the Jews, not for the crucification rather for the advent of Christianity and the superstitions and injustices followed by monotheistic religions. Many also alienated the Jews further by claiming their religion to be a primitive version of Christianity. Being alienated from society proved to also be of use as they formed a tight-knit Jewish community.

A major European event was the black death, a plague that was bought onto it by rodents that were transported all through the continent. In the UK, due to the Jews being alienated, they had been blamed for the outbreak of the black death. This belief was spread fast as many had a lot of prejudice against the Jews. This was a series of violent attacks, mass persecutions and massacres of Jews during the Black Death. The Jewish community was also banned from the UK and other countries based on prejudices and false assumptions. Due to this, the influence of the Jewish community was haltered in the UK. This allowed a mass spread of even more stereotypes against the Jews because the people didn’t have any real example to oppose them. For example, the depictions of Jews in Shakespeare's plays were based entirely on his prejudice. In reality, while some of each ethnicity may be money minded and cruel, not all Jews are like that. Works of the time were similar to his in spreading stereotypes of Jews and other communities as real. This is a huge reason for the world’s antisemitism.

There have been various examples of Jewish persecutions but perhaps the biggest one is the holocaust. The holocaust was a mass genocide of Jews during WW2. At the time, Germany was still recovering from its defeat in the First World War. The people at the time were angry and needed something to direct it at. The government at the time took advantage of that. They spread rumours that are later to be called Stab-In-The-Back rumours. They claimed that they had lost the war from the inside. They stated that many of the citizens were Jewish immigrants that were influencing the country and government to their needs. They also told that the Jews had been gnawing down on the German culture. They also claimed that the Jews had been behind the protests in the country during the first world war that were anti-german and were the reason for Germany’s defeat. The Jews were labelled as outcasts. Many of the citizens joined the antisemitic movement due to their prejudices against the Jews that were fuelled by the rumours. Leaders such as Hitler started concentration camps for the Jews who were made to do hard labour and were tortured. Many were killed when they were unable to work anymore. Many Jews fled the country and took refuge in the Allied countries. This was one of the bloodiest Jewish persecutions in history that we know of and was a truly sad story.

History is taught in school so that we understand how it affects the present (well, at least partly for that reason). All these persecutions of Jews would have some effect, right? Actually, they have had some. The Jewish community, especially the Israelites are nowadays very protective of their land to the point of going to war. They have been known to bully countries like Palestine to get back what is theirs. While their actions are not justified, we can understand through human psychology why they would do such. I would like to clarify that I’m not claiming that all modern Jews are now warmongers because of their history, it is just that some politicians choose to be such and get back their ancestral land.
    `
  },

  {
    slug: "black-hole-information-paradox",
    title: "Black Hole Information Paradox",
    date: "2021-12-02",
    category: "physics",
    status: "evergreen",
    description: "What information really is, and why black holes seem to threaten it.",
    featured: false,
    draft: false,
    body: `
**What is information? A word that we use every day but has a deeper
meaning than we comprehend. Take an example of a diamond, a stone
with exorbitant prices commonly used to make jewellery. Now, take a
look at graphite, ordinary, everyday, mundane. These two are made of
the same substance, carbon, but are so wildly different. Information
sets them apart, something abstract, but a thing that holds the
universe together in the most elegant of manners. Much of our
modern physics and ultimately all sciences are based on one law:
Information can never be destroyed. When we go near black holes,
the most extreme objects in the universe, everything starts to get
hazy...**

**Black holes are essentially an area of gravitation so infinitely dense
that it is like a trap door for the stage that is space-time. They are the
opposite of information. While it sets things apart, black holes take
different things and make them the same. This is deleting the
information of the matter that the particles were once part of. This
creates the information paradox. This theory can be visualized by a
simple thought experiment below:**

**Imagine two fluids, water and oil which floats on top of it. Now
imagine yourself and all matter in the universe to be waves of
different shapes and sizes in the oil. The oil represents the Higgs
field, a field where various fluctuations (waves) result in the
formation of fundamental particles. The water represents the space-
time continuum in which we live. Space-time is affected by the
density and strength of the waves in the oil that represents matter. A
black hole is represented by a whirlpool going through both the
liquids. This whirlpool cancels out the matter (waves in the oil). Thus
the information about the matter is lost.**

**If this were true, we would have to go back and redo much of our
sciences, postponing any new inventions by centuries. It forces us to
rebuild our civilisation and rethink our understanding of our universe.
This world would be quite post-apocalypse with many people taking
the opportunity to spread ignorance like in the pre-enlightenment
period in Western Europe. While this is all very dark, it is not the only
possibility.**

**Black holes are full of unicorns and treasure pots at the end of**

**rainbows, prove me wrong! You can’t. Since anything that enters a
black hole can never leave, who knows what is inside a black hole?
Maybe there is an entire universe inside a black hole that we just can’t
access unless of course, we are willing to never come back. And who
knows, maybe we can bend science just enough that we can actually
get out of a singularity. This can open many possibilities for us such
as using black holes as colossal hard drives, entire universes to
expand to, and even from a realtor’s side, more land!!!**

**The universe is a hologram:

How the black holes store data is a topic that leads to new and
interesting conclusions. It is theorized that a black hole expands by a
tiny bit each time it devours any matter. This could mean that the
black hole is actually saving the matter's information at its surface. If
you fall into a black hole would meet with all that had previously fallen
into the black hole and experience the 3 dimensions. Everything you
see would be information spread on the surface of a black hole. This
is sort of like a hologram or a 3-D image. This could also open the
possibility that we live on the surface of a black hole!**
    `
  },

  {
    slug: "stars-from-birth-to-death",
    title: "Stars- From birth to death",
    date: "2021-06-28",
    category: "physics",
    status: "evergreen",
    description: "The life cycle of a star, from nebula to white dwarf, neutron star or black hole.",
    featured: false,
    draft: false,
    body: `
Many of you must have found yourself staring at a wondrous night-sky filled with billions of stars, and a question must have occurred to you: what are they, and how do they glow? First and foremost, consider the birth of stars. Nebulas, which are extremely large gas clouds in space, form stars. These are primarily made up of hydrogen and helium. Due to their massive weight, the gas particles eventually become attracted to one another and collide. As they resist gravity, the particles in the gas cloud heat up into plasma. A process known as "Nuclear fusion" begins to take place in the core of the newborn star. Nuclear fusion occurs when two or more atoms combine to form a heavier element, releasing massive amounts of energy in the form of light. This energy escapes from the newly formed star, providing heat and light. This type of nuclear fusion occurs throughout the star's lifetime, creating a delicate balance between the star imploding due to gravity and expanding due to fusion. A star dies when it has depleted all of its hydrogen.

There are two ways for stars to die:

Stars less than twice the mass of the sun expand into red giants during its final days. During this time as red giants, stars use up most of their fuel before collapsing into white dwarfs. White dwarfs are stars which shine very slowly and dimly. This is because nuclear fusion is much slower as it is in the stage of fusing heavier elements and the star isn't very dense now, putting less pressure on the nuclear fusion.

Stars more than twice the mass of the sun fuse their elements until they reach iron. At this point, it stops fusion and rapidly implodes. This results in a supernova. Supernovas are so powerful that they make all of the heavier elements in the periodic table from fusion at once. A star can become a neutron star or a black hole after a supernova takes place.

A diagram showing the life cycle of a star:

![Life cycle of a star diagram](assets/img/writing/stars-1.jpg)

When the fusion rate exceeds the gravity, the star implodes into a super dense star. This is called a neutron star. The extreme gravitational conditions in neutron stars cause electrons to escape. Aside from that, protons fuse together to form neutrons and three up quarks (fundamental particles). To visualise the density of a neutron star, consider a marble with the mass of a car to visualise the density of a neutron star.

![Neutron stars video thumbnail](assets/img/writing/stars-2.jpg)

A black hole, on the other hand, occurs when gravity triumphs and the star is compressed to extremely small scales. For example, if the sun was to ever transform into a black hole, it would have a diameter of 2 miles. Black holes, in a physical are described as an infinitely dense point in spacetime.

![Diagram of black hole regions](assets/img/writing/stars-3.jpg)
    `
  },

  {
    slug: "casinos-bright-light-attractions-or-daylight-robbers",
    title: "Casinos: Bright light attractions or daylight robbers?",
    date: "2021-06-22",
    category: "maths",
    status: "evergreen",
    description: "The mathematics of why casinos always win — and why 'smart' play cannot beat the house.",
    featured: false,
    draft: false,
    body: `
Ah! Casinos! The lights! The thrills! The lotteries!!, but wait, it has a dark side. Many of you adult readers may or may not have gone to a casino, but did you know that it is the biggest theft industry that is approved by the government? That's right, the casinos have a carefully calculated system that wins most of the time without being too suspicious and you can't even beat smart with smart as it is against the law to use any shred of intelligence there. How do casinos do this? Let's find out.

Casinos use the mathematics of probability, in simple probability, the probability of a coin landing on heads is equal to it landing on tails because of there being two sides. Even with more sides, the probability is always 100%/ number of sides. But how can such giants make is much money with such a small concept? They don't. That was just a simple representation of probability but casino's take in account every small detail, the spin, the momentum, the velocity, everything! Using all that data they create a system which allows them to cheat while keeping the general public playing.

So Casinos are big theft industries, so how are they compatible with the law? The government allows the casinos because they are good for the economy. How? Easy, the big casinos attract so many tourists every year, it practically keeps the economy afloat. So, it is my request to you, no matter how lucky you feel, don't go straight to the thieves den. If many people do this, sure, the economy will go down a bit, but in the long run, it will rid us of those theives that rob us right under the police's nose.
    `
  },

  {
    slug: "the-avengers-endgame-theory",
    title: "The Avengers Endgame Theory",
    date: "2020-10-21",
    category: "physics",
    status: "evergreen",
    description: "Using Avengers: Endgame to ask whether the quantum realm could actually work as a time machine.",
    featured: false,
    draft: false,
    body: `
To all marvel fans and lovers, this blog is exclusively dedicated for you, but chin up those who aren't in that category because this is going to be an interesting article.

Many of you have seen avengers endgame and probably have some questions with you-

Was Ant-Man correct about time being different in the quantum realm?

Can we harness that time shift to make time machines?

Is it science fiction or possible reality?

Sit back as you are going to get answers to all those questions in my personal info sponge view.

First off for the people who didn't watch Avengers Endgame, what did the goofy Ant-Man say that shook the Earth? Well as Ant-Man was trapped in the quantum realm for years, he stated to the surprise of many, that for him, it only felt like days.

So, is this true, that time in the quantum realm goes at a different velocity* than in the macroscopic realm? Well yes.... So how does it work-

In Einstein's theory of general relativity he stated and it was proven that time goes slower in the presence of gravity, but it is only significant enough to notice when near an object with immensely high gravitational energy. Even though not significant, Earth's gravity dilates time with respect to other places with no massive body to support any much gravity.

Here you go, though flawed, the Avengers Endgame theory still makes sense from the scientific magnifying glass. But time travel is really dangerous as if you change anything major, you change everything. For Example-

Take an example that you go back in time and you kill one of your long line of ancestors because you don't know him. We will also take in consideration that his successor is not born, thus you indirectly killed yourself.

This was only an example for many many of the paradoxes possible by changing anything (even accidentally) by time travel. The paradoxes problem with time travel is only one of the problem in time travel, it can also increase the crime rate.

* I used velocity as time is thought to have two directions and maybe even more!
    `
  },

  {
    slug: "from-the-big-bang-to-the-end-of-the-universe",
    title: "From the big bang to the end of the universe",
    date: "2020-09-22",
    category: "physics",
    status: "evergreen",
    description: "From the big bang to the heat death of the universe, in one long arc.",
    featured: false,
    draft: false,
    body: `
When Einstein developed the general theory of relativity,
he was not satisfied with it as he believed that the universe should be stable.
After a lot of thinking he added a new cosmological
constant which is the opposite of gravity, if gravity attracts things it
repels things. It worked out well until scientist discovered that the universe
was expanding. Edwin Hubble found out that two different
galaxies were moving apart from each other using the doppler
effect theory which states that wavelengths get shorter the closer the
object moves towards you. Einstein was puzzled by this. Although he strongly believed
in a more stable universe, his work on the expansion of the universe ended up
making him the rightful owner of the theory, even if he didn’t want to be. This
theory led scientists to believe in a ‘big bang’
and that everything started out from a single singularity
and spread out to the universe
we know and believe in today. They even conceptualized a new energy particle corresponding
to this- Dark energy (Anti-Gravity). A few years later, to the surprise of many, it
was calculated that the rate of expansion is speeding up, which led theoretical
physicists to postulate three ways the
universe might end:

· Big Crunch

The scenario in which gravity
overcomes dark energy and results in everything coming together into a dense,
massive singularity (much like the opposite of big bang).

· Heat death

When dark energy stretches gravity
to the point it loses its pull and the universe continuously expands at a constant velocity for ever losing
all sources of heat.

· Big Rip

When gravity is overcome by
dark energy by so much that it also overcome the nuclear and electromagnetic
forces that hold together atoms ripping all matter in the universe.
    `
  },

  {
    slug: "cloning-biological-and-physical",
    title: "Cloning, Biological and Physical.",
    date: "2020-09-16",
    category: "biology",
    status: "evergreen",
    description: "Biological and physical cloning: what Dolly the sheep actually proved, and where the idea goes from there.",
    featured: false,
    draft: false,
    body: `
If you are a science fiction lover, you must have dreamt of cloning, but have you ever wondered how does cloning work and what are its dangers? Believe it or not, cloning was real, but not the cloning you would imagine, but biological cloning.

In 1996, dolly the sheep was successfully cloned by fusing the nucleus from a mammary-gland cell of a Finn Dorset ewe into an enucleated egg cell taken from a Scottish Blackface ewe. Biological cloning is almost like passing down of genes from parents but is performed in laboratories.

Recent studies have shown that genetic engineering, which is recent technology can remove the child is prone to inherit from the parent thus making a "perfect child" it seems cool and nice for sometime after you hear it, but it is an horror as it takes away all your individuality and personality and leaves you as a child shaped robot.
Wait, that's getting too much into biological cloning, let's discuss physical cloning, which means everything same to the subatomic level, the charge, the spin, the position, etc. The method best candidate for physical cloning is a machine that measures all the features of the main body you want to clone and arrange some raw materials in the very same way.

Even though it sounds so, it is not so easy as there are some problems and the major one is lies in the Heisenberg uncertainty principle-

The Heisenberg uncertainty principle states that at the subatomic level, the more the certainty in the speed of the particle, atom, or molecule, the more uncertain the position the object, vice versa. There is but one solution to this problem that we take a number of the same thing, all identical even to the subatomic level, and then we measure different attributes of the object on individual objects eg. Measure height in one, weight in one, position in one and speed in one, etc.

But don't get your hopes up for physical cloning as getting these completely identical objects is impossible in today's understanding, and don't try any type of cloning as it is very dangerous and certainly don't try to alter personalities as it destroys the value of human individuality.
    `
  }

];
